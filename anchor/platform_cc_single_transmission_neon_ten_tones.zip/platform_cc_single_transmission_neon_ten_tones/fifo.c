#include "fifo.h"
#include "global_variables.h"
#include "write_wav.h"
//implement a fifo simply using array

#define SIZE	10

short fifo_buffer[REC_BUFFER_LEN * SIZE];
int fifo_buffer_size = REC_BUFFER_LEN * SIZE;
unsigned int current_index = 0;
unsigned int read_index = 0;
bool is_pushing = false;

sem_t sem_fifo; // using this bitch cost me around 150ms 
/*
function: using an array to emulate an FIFO
	init the fifo buffer 
*/
void fifo_init()
{
	memset(fifo_buffer, 0, sizeof(short) * fifo_buffer_size);
	current_index = 0;
	read_index = 0;
	sem_init(&sem_fifo, 1, 0);
}

/*
function: push the new captured data to the fifo buffer
input: data - captured audio data 
*/
void push(short* data)
{
	is_pushing = true;
	memcpy(fifo_buffer + (current_index % SIZE) * REC_BUFFER_LEN, data, REC_BUFFER_LEN * sizeof(short));
	current_index++;
	is_pushing = false;
	sem_post(&sem_fifo);
}
/*
function: pop out the data the src buffer
output: data - src buffer that store the poped out data
*/
void pop(short* data)
{
	//while(is_pushing == true);
	//while(read_index <= current_index)
	sem_wait(&sem_fifo); // wait for new buffer data
	//while(read_index == current_index);
	//if(read_index < current_index || (current_index == 0 && read_index != 0)) // the second condition is used to avoid data overflow
	//{
		memcpy(data, fifo_buffer + (read_index % SIZE) * REC_BUFFER_LEN, REC_BUFFER_LEN * sizeof(short));
		read_index++;
	//}
}

/*void debug_fifo_data(int i)
{
	write_short_txt();
}*/