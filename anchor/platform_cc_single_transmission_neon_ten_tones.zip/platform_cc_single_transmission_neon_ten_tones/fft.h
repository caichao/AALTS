#ifndef FFT_H
#define FFT_H


extern void cdft(int n, int isgn, float *a);

#endif

