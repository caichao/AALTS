#include "upload_thread.h"
#include "json_wraper.h"

sem_t sem_upload;

void upload_timestamp(int first_anchorId, int second_anchorId, int tdoa)
{
	memset(upload_message, 0, sizeof(char) * SEND_MESSAGE_LEN);
	encode_timestamp(first_anchorId, second_anchorId, tdoa, upload_message);
	//memcpy(upload_message, msg, strlen(msg));
	sem_post(&sem_upload);
}

void upload_capture_beacon_message(CaptureBeaconMessage capture_beacon_message)
{
	memset(upload_message, 0, sizeof(char) * SEND_MESSAGE_LEN);
	encode_captured_beacon_message(capture_beacon_message, upload_message);
	sem_post(&sem_upload);
}

void *UploadThread()
{
  sem_init(&sem_upload, 1, 0);
  memset(&upload_message, 0, sizeof(char) * SEND_MESSAGE_LEN);
  int sock;
  struct sockaddr_in servAddr; // server address structure
  /*char *servIP = SERVER_IP;
  unsigned short servPort = SERVER_PORT;*/
  char *servIP = g_parameter.server_ip;
  unsigned short servPort = g_parameter.upload_port;
  memset(&servAddr, 0, sizeof(servAddr));
  servAddr.sin_family = AF_INET;
  servAddr.sin_addr.s_addr = inet_addr(servIP);
  servAddr.sin_port = htons(servPort);
  if ((sock = socket(PF_INET, SOCK_STREAM, IPPROTO_TCP)) < 0) {
    perror("[upload thread] socket() failed");
    exit(1);
  }
  if (connect(sock, (struct sockaddr *) &servAddr, sizeof(servAddr)) < 0) {
    perror("[upload thread] connect() failed");
    // TODO: just try connect later
    //exit(1);
  }
  printf("upload thread is ready\n");
  while(1)
  {
	  sem_wait(&sem_upload);
	  //printf("trying to send a upload_message\r\n");
	  //send(sock, "upload_message from anchor", 20,0); ///send to the server
	  send(sock, upload_message, strlen(upload_message),0);
  }
  
  sem_destroy(&sem_upload);
  close(sock);
}