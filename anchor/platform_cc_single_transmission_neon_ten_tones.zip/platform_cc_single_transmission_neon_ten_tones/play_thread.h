#ifndef PLAY_THREAD_H
#define PLAY_THREAD_H

#include "basic_headers.h"

#include "acoustic.h"

//#define PLAY_BUFFER_LEN 4800


//extern short play_buffer[PLAY_BUFFER_LEN];
//extern bool is_time_to_play;
extern void *PlayThread(void *playThreadArgs);
extern void transmit_beacon_message();
struct PlayThreadArgs
{
  snd_pcm_t* device;
  //short* p_play_buffer;
};

#endif


