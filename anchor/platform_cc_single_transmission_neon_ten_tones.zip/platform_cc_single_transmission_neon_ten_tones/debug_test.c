#include <string.h>
#include <stdio.h>
#include "write_wav.h"
#include "acoustic.h"

int main(int argc, char** argv)
{
	/*int i = 0;
	int a[] = {1,2,3,4,5,6,7,8,9,10};
	int* b = NULL;
	int c[5] = {0};
	int *p = &a[4];
	memcpy(c, p, sizeof(int)*5);
	
	for(i = 0; i < 5; i++)
	{
		printf("%d ",c[i]);
	}*/
	init();
	return 0;
}