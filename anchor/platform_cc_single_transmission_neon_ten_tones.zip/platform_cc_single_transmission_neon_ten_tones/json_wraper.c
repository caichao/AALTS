#include "json_wraper.h"


char tmp[TMP_BUFFER_LEN] = {0};
/**
function: encode the anchor id and tdoa timestamp in the des char array
input:  anchorId - self unique id in the network, loaded from global_prams.txt
		tdoa - detected timestamp of up and down preamble time difference
output: msg - des char array in json format
*/
void encode_timestamp(int first_anchorId, int second_anchorId, int tdoa, char *msg)
{
	json_object *time_stamp;
	time_stamp = json_object_new_object();
	
	memset(tmp, 0, sizeof(char) * TMP_BUFFER_LEN);	
	sprintf(tmp, "%d", first_anchorId);
	json_object_object_add(time_stamp, FIRST_ANCHORID, json_object_new_string(tmp));

	memset(tmp, 0, sizeof(char) * TMP_BUFFER_LEN);	
	sprintf(tmp, "%d", second_anchorId);
	json_object_object_add(time_stamp, SECOND_ANCHORID, json_object_new_string(tmp));
	
	memset(tmp, 0, sizeof(char) * TMP_BUFFER_LEN);	
	sprintf(tmp, "%d", tdoa);	
	json_object_object_add(time_stamp, TDOA, json_object_new_string(tmp));
	
	sprintf(msg, "%s", json_object_to_json_string(time_stamp));
	json_object_put(time_stamp);//free 
	
	printf("[Encode message:] %s", msg);
	
}

/*
function: encode the captured beacon message in json format

*/
void encode_captured_beacon_message(CaptureBeaconMessage capture_beacon_message, char* msg)
{
	json_object *time_stamp;
	time_stamp = json_object_new_object();
	
	memset(tmp, 0, sizeof(char) * TMP_BUFFER_LEN);
	sprintf(tmp, "%s", "anchor");
	json_object_object_add(time_stamp, "role", json_object_new_string(tmp));
	
	memset(tmp, 0, sizeof(char) * TMP_BUFFER_LEN);	
	sprintf(tmp, "%d", capture_beacon_message.self_anchorId);
	json_object_object_add(time_stamp, "selfAnchorId", json_object_new_string(tmp));
	
	memset(tmp, 0, sizeof(char) * TMP_BUFFER_LEN);	
	sprintf(tmp, "%d", capture_beacon_message.captured_anchorId);	
	json_object_object_add(time_stamp, "capturedAnchorId", json_object_new_string(tmp));

	memset(tmp, 0, sizeof(char) * TMP_BUFFER_LEN);	
	sprintf(tmp, "%d", capture_beacon_message.captured_sequence);	
	json_object_object_add(time_stamp, "capturedSequence", json_object_new_string(tmp));

	memset(tmp, 0, sizeof(char) * TMP_BUFFER_LEN);	
	sprintf(tmp, "%d", capture_beacon_message.preamble_index);	
	json_object_object_add(time_stamp, "preambleIndex", json_object_new_string(tmp));	
	
	memset(tmp, 0, sizeof(char) * TMP_BUFFER_LEN);	
	sprintf(tmp, "%ld", capture_beacon_message.looper_counter);	
	json_object_object_add(time_stamp, "looperCounter", json_object_new_string(tmp));
	
	sprintf(msg, "%s", json_object_to_json_string(time_stamp));
	json_object_put(time_stamp);//free 
	
	printf("[Encode message:] %s", msg);	
}

/*void encode_timestamp(int anchorId, int tdoa, char *msg)
{
	json_object *time_stamp;
	time_stamp = json_object_new_object();
	
	memset(tmp, 0, sizeof(char) * TMP_BUFFER_LEN);	
	sprintf(tmp, "%d", anchorId);
	json_object_object_add(time_stamp, ANCHOR_ID, json_object_new_string(tmp));
	
	memset(tmp, 0, sizeof(char) * TMP_BUFFER_LEN);	
	sprintf(tmp, "%d", tdoa);	
	json_object_object_add(time_stamp, TDOA, json_object_new_string(tmp));
	
	sprintf(msg, "%s", json_object_to_json_string(time_stamp));
	json_object_put(time_stamp);//free 
	
	printf("[Encode message:] %s", msg);
	
}*/

/**
function: determine whether it is time to transmit beacon message
input: anchorId - network unique anchor id
       msg - received strings
output: bool - if true, anchor transmit beacon message
*/
bool is_my_timeslot(int anchorId, const char* msg, int *sequence)
{
	bool can_we_start = false;
	memset(tmp, 0, sizeof(char) * TMP_BUFFER_LEN);
	memcpy(tmp, msg, strlen(msg));
	// the step to decode the tdoa information
	json_object *result_json = json_tokener_parse(tmp);
    json_object *tmp_obj = json_object_object_get(result_json, "anchorId");
    int parsed_anchorId = json_object_get_int(tmp_obj);
	if(parsed_anchorId == anchorId)
	{
		can_we_start = true;
	}
	tmp_obj = json_object_object_get(result_json, "sequenceId");
	*sequence = json_object_get_int(tmp_obj);
	json_object_put(tmp_obj);//free	
	//printf("anchorId=%d, decoded anchorId = %d, sequenceId=%d\n", anchorId, parsed_anchorId, *sequence);
	return can_we_start;
}

/**
function: determine whether it is time to transmit beacon message
input: anchorId - network unique anchor id
       msg - received strings
output: bool - if true, anchor transmit beacon message
*/
/*bool is_my_timeslot(int anchorId, const char* msg)
{
	bool can_we_start = false;
	memset(tmp, 0, sizeof(char) * TMP_BUFFER_LEN);
	memcpy(tmp, msg, strlen(msg));
	// the step to decode the tdoa information
	json_object *result_json = json_tokener_parse(tmp);
    json_object *tmp_obj = json_object_object_get(result_json, "anchorId");
    int parsed_anchorId = json_object_get_int(tmp_obj);
	if(parsed_anchorId == anchorId)
	{
		can_we_start = true;
	}
	json_object_put(tmp_obj);//free	
	//printf("anchorId=%d, tdoa=%d\n", anchorId, tdoa);
	return can_we_start;
}*/

/**
function: decode the message from server that is in the json format
input: anchorId - network unique anchor id
	   msg - json format message from the server
output: type - char array that store the decode message either "up" or "down"
		bool - if true, anchor transmit [type] preamble, if not, ignore that 
*/
bool decode_timestamp(int anchorId, char *type, const char* msg)
{
	bool can_we_start = false;
	memset(tmp, 0, sizeof(char) * TMP_BUFFER_LEN);
	memcpy(tmp, msg, strlen(msg));
	// the step to decode the tdoa information
	json_object *result_json = json_tokener_parse(tmp);
    json_object *tmp_obj = json_object_object_get(result_json, PARITY);
    int parity = json_object_get_int(tmp_obj);
	if(parity == anchorId % 2)
	{
		// it is time for me to send beacon message, but I need to get the chirp type
		memset(tmp, 0, sizeof(char) * TMP_BUFFER_LEN);	
		sprintf(tmp, "%d", anchorId);
		tmp_obj = json_object_object_get(result_json, tmp);
		const char *inner = json_object_get_string(tmp_obj);
		memcpy(type, inner, strlen(inner));
		printf("I am anchor = %d, emit %s chirp\n", anchorId, type);
		can_we_start = true;
	}
	json_object_put(tmp_obj);//free	
	//printf("anchorId=%d, tdoa=%d\n", anchorId, tdoa);
	return can_we_start;
}

/**
function: load parameters from local txt file 
input: file_path - file name of the txt file
output: parameters - structure data that store all the loaded parameters including
		server ip address
		port number to listen broadcast message
		port number to upload tdoa timestamp to the server
		anchor ID
		detection threshold for preamble 
*/
void load_prameter_profiles(const char* file_path, Parameters* parameters)
//void load_prameter_profiles()
{
	//json_object *file_obj = json_object_from_file(file_path);  //read json_object from file
    json_object *file_obj = json_object_from_file("global_prams.txt"); 
	json_object *tmp_file = json_object_object_get(file_obj, "server_ip");
	//memset(parameters->server_ip, 0, 15);
	const char* server_ip = json_object_get_string(tmp_file);
	//printf("sever ip = %s\n", server_ip);
	memcpy(parameters->server_ip, server_ip, strlen(server_ip));
	
	tmp_file = json_object_object_get(file_obj, "schedule_port");
	parameters->schedule_port = json_object_get_int(tmp_file);
	//int schedule_port = json_object_get_int(tmp_file);
	//printf("schedule_port = %d\n", schedule_port);
	
	tmp_file = json_object_object_get(file_obj, "upload_port");
	//int upload_port = json_object_get_int(tmp_file);
	//printf("schedule_port = %d\n", upload_port);
	parameters->upload_port = json_object_get_int(tmp_file);

	tmp_file = json_object_object_get(file_obj, "anchorId");
	//int anchorId = json_object_get_int(tmp_file);
	//printf("anchorId = %d\n", anchorId);
	parameters->anchorId = json_object_get_int(tmp_file);	
	
	tmp_file = json_object_object_get(file_obj, "preamble_threshold");
	//int anchorId = json_object_get_int(tmp_file);
	//printf("anchorId = %d\n", anchorId);
	parameters->detection_threshold = json_object_get_int(tmp_file);	
	
	//int anchorId = json_object_get_int(tmp_obj);
    //int tdoa = json_object_get_int(tmp_obj);
	//printf("server_ip = %s, schedule_port = %d, upload_port = %d, anchorId = %d\n", parameters->server_ip, parameters->schedule_port, parameters->upload_port, parameters->anchorId);
	//json_object_put(tmp_file);//free
	json_object_put(file_obj);//free
}