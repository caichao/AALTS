#include "main.h"

/*
In this version, all the anchor transmit up preamble
*/


int main(int argc, char *argv[])
{
  printf("[main thread]program start --------------\r\n");

  // init acoustic related buffer such as preamble, symbol
  init();
  // load profiles: ip, port, anchorId, etc
  global_variable_initializer();
  // first open the mic amplifier
  open_mic_amplifier();
  
  exec_playing();
  exec_scheduling();
  
  exec_uploading();
  exec_recording(); // the recording thread has to be placed ahead or the program will be jammed
  
  exec_decoding();
 
  
  
  
  
  //encoding_beacon_message(1, UP);
  //transmit_beacon_message();
  
  //upload_timestamp(1, 1234);
  //upload_timestamp("this timestamp from anchor nodes");
  
  printf("[main thread]program over ---------------\r\n");
  while(1);
  return 1;
}

void open_mic_amplifier()
{
  if (!bcm2835_init())
    return;
  // Set the pin to be an output
  bcm2835_gpio_fsel(PIN_AMPLIFIER_SWITCH, BCM2835_GPIO_FSEL_OUTP);
  // Set the pin to be HIGH (with mic amplifier) (defaulut is LOW, without mic amplifier)
  bcm2835_gpio_write(PIN_AMPLIFIER_SWITCH, HIGH);
  printf("[main thread] MicAmp ON\n");   
}


void exec_recording()
{
  int err;
  // capture
  snd_pcm_t *capture_handle;
  char *snd_device_in  = "plughw:0,0";
  if ((err = snd_pcm_open(&capture_handle, snd_device_in, SND_PCM_STREAM_CAPTURE, 0)) < 0) { // 0:block, 1:SND_PCM_NONBLOCK
    fprintf (stderr, "cannot open audio device %s (%s)\n", snd_device_in, snd_strerror (err));
    exit (1);
  }
  configure_alsa_audio(capture_handle);

  // for recording
  pthread_t recordThread;
  struct RecordThreadArgs *recordThreadArgs;
  if ((recordThreadArgs = (struct RecordThreadArgs *) malloc(sizeof(struct RecordThreadArgs))) == NULL) {
    perror("malloc() failed");
    exit(1);
  }
  recordThreadArgs->device = capture_handle;
  recordThreadArgs->p_audio_buffer = audio_buffer;

  //isRecordThreadOn = true;
  if (pthread_create(&recordThread, NULL, RecordThread, (void *) recordThreadArgs) != 0) {
    perror("pthread_create() failed");
    exit(1);
  }
}

void exec_playing()
{
  // playback
  int err;
  snd_pcm_t *playback_handle;
  char *snd_device_out = "plughw:0,0";
  if ((err = snd_pcm_open(&playback_handle, snd_device_out, SND_PCM_STREAM_PLAYBACK, 0)) < 0) { // 0:block, 1:SND_PCM_NONBLOCK
    fprintf (stderr, "cannot open audio device %s (%s)\n", snd_device_out, snd_strerror (err));
    exit (1);
  }
  configure_alsa_audio(playback_handle);  
  
  // for playing
  pthread_t playThread;
  struct PlayThreadArgs *playThreadArgs;
  if ((playThreadArgs = (struct PlayThreadArgs *) malloc(sizeof(struct PlayThreadArgs))) == NULL) {
    perror("malloc() failed");
    exit(1);
  }
  playThreadArgs->device = playback_handle;
  
  if (pthread_create(&playThread, NULL, PlayThread, (void *) playThreadArgs) != 0) {
    perror("pthread_create() failed");
    exit(1);
  }  
}

void exec_decoding()
{
  // for decoding
  pthread_t decodingThread;
  /*struct PlayThreadArgs *playThreadArgs;
  if ((playThreadArgs = (struct PlayThreadArgs *) malloc(sizeof(struct PlayThreadArgs))) == NULL) {
    perror("malloc() failed");
    exit(1);
  }
  playThreadArgs->device = playback_handle;*/
  
  if (pthread_create(&decodingThread, NULL, DecodeThread, NULL)) {
    perror("pthread_create() failed");
    exit(1);
  }  
}

void exec_uploading()
{
  pthread_t uploadingThread;
  if (pthread_create(&uploadingThread, NULL, UploadThread, NULL)) {
    perror("pthread_create() failed");
    exit(1);
  } 	
}

/*
the secheduling thread is used to determine when to emit beacon message
this process is manipulated by a remote server
the client execute the secheduling via listening a broadcast message
*/
void exec_scheduling()
{
  pthread_t schedulingThread;
  if (pthread_create(&schedulingThread, NULL, ScheduleThread, NULL)) {
    perror("pthread_create() failed");
    exit(1);
  }  
}

//======================================================================
// ALSA
//======================================================================
int configure_alsa_audio(snd_pcm_t *device)
{
  int err;
  snd_pcm_hw_params_t *hw_params;

  if ((err = snd_pcm_hw_params_malloc (&hw_params)) < 0) { // snd_pcm_hw_params_alloca
    fprintf (stderr, "cannot allocate hardware parameter structure (%s)\n", snd_strerror (err));
    exit (1);
  }

  if ((err = snd_pcm_hw_params_any (device, hw_params)) < 0) {
    fprintf (stderr, "cannot initialize hardware parameter structure (%s)\n", snd_strerror (err));
    exit (1);
  }

  if ((err = snd_pcm_hw_params_set_access (device, hw_params, SND_PCM_ACCESS_RW_INTERLEAVED)) < 0) {
    fprintf (stderr, "cannot set access type (%s)\n", snd_strerror (err));
    exit (1);
  }

  if ((err = snd_pcm_hw_params_set_format (device, hw_params, SND_PCM_FORMAT_S16_LE)) < 0) {
    fprintf (stderr, "cannot set sample format (%s)\n", snd_strerror (err));
    exit (1);
  }

  unsigned int tmp = SAMPLE_RATE;
  if ((err = snd_pcm_hw_params_set_rate_near (device, hw_params, &tmp, 0)) < 0) {
    fprintf (stderr, "cannot set sample rate (%s)\n", snd_strerror (err));
    exit (1);
  }
  //printf("[SAMPLE_RATE] ================ sampling rate: %d =================\n", (int) tmp);

  if ((err = snd_pcm_hw_params_set_channels (device, hw_params, 1)) < 0) {
    fprintf (stderr, "cannot set channel count (%s)\n",
       snd_strerror (err));
    exit (1);
  }

  /*
  snd_pcm_uframes_t p_size_max;
  snd_pcm_uframes_t p_size;
  snd_pcm_hw_params_get_buffer_size_max(hw_params, &p_size_max);
  snd_pcm_hw_params_get_buffer_size(hw_params, &p_size);
  printf("[SIZE] %d, %d \n", (int) p_size_max, (int) p_size);
  */
  ////err = snd_pcm_hw_params_set_buffer_size(device, hw_params, p_size_max);
  snd_pcm_uframes_t val = SAMPLE_RATE*4; // = 192000 , max:120422,131072
  err = snd_pcm_hw_params_set_buffer_size_near(device, hw_params, &val);
  if (err < 0) {
    printf("Unable to set buffer size %li: %s\n", val, snd_strerror(err));
    exit (1);
  }
  //printf("[SIZE] ================ buffer size: %d =================\n", (int) val);
  /*
  snd_pcm_hw_params_get_buffer_size_max(hw_params, &p_size_max);
  snd_pcm_hw_params_get_buffer_size(hw_params, &p_size);
  printf("[SIZE] %d, %d \n", (int) p_size_max, (int) p_size);
  */

  //After this call, snd_pcm_prepare() is called automatically and the stream is brought to SND_PCM_STATE_PREPARED state.
  if ((err = snd_pcm_hw_params (device, hw_params)) < 0) {
    fprintf (stderr, "cannot set parameters (%s)\n", snd_strerror (err));
    exit (1);
  }

  snd_pcm_hw_params_free (hw_params);

  /* unnecessary, TBD
  if ((err = snd_pcm_prepare (device)) < 0) {
    fprintf (stderr, "cannot prepare audio interface for use (%s)\n", snd_strerror (err));
    exit (1);
  }
  */

  return 0;
}

