#ifndef MAIN_H
#define MAIN_H
//---------------------------------------

//========================================
// customized header files
//========================================
#include "global_variables.h"

#include "acoustic.h"

#include "play_thread.h"

#include "record_thread.h"

#include "decode_thread.h"

#include "schedule_thread.h"

#include "upload_thread.h"

#include "json_wraper.h"
//========================================
// macro
//========================================


// enable output io
//#define DEBUG

//========================================
// function declaration
//========================================
void open_mic_amplifier();
void exec_recording();
void exec_playing();
void exec_decoding();
void exec_scheduling();
void exec_uploading();
int configure_alsa_audio(snd_pcm_t *device);
//---------------------------------------
#endif


