#include "record_thread.h"
#include "fifo.h"

sem_t sem_recorder;
int counter = 0;


//#define DEBUG_WAVE

void increase_counter()
{
	printf("[+++++increase]counter = %d\r\n", ++counter);
}
void decrease_counter()
{
	printf("[-----decrease]counter = %d\r\n", --counter);
}

void is_recording_ready()
{
	//sem_wait(&sem_recorder);
}

void *RecordThread(void *recordThreadArgs)
{
  //setSchedulerHighestPriority();

  struct RecordThreadArgs *args = (struct RecordThreadArgs *)recordThreadArgs;
 
  int r;
  int err;
  //int readSmpls;
  printf("record thread is ready \n");
  
  fifo_init();
  #ifdef DEBUG_WAVE
	  int packet_length = 200;
	  short *mic_data = (short *)malloc(packet_length * REC_BUFFER_LEN * sizeof(short));
	  int index = 0;
	  int i = 0;
	  short *p = NULL;
  #endif
  printf("[RecordThread is ready] \n");
  
  //#define DEBUG_RECORD_INTERVAL
  while (1)
  {
    //is_recording_ready = false;
    // note: for blocking mode, r == readSmpls
	#ifdef DEBUG_RECORD_INTERVAL
	clock_t begin = clock();
	#endif
	
    r = snd_pcm_readi(args->device, args->p_audio_buffer, REC_BUFFER_LEN);
	push(args->p_audio_buffer);
	//increase_counter();
	//sem_post(&sem_recorder);
	//printf("[RecordThread:] r = %d \r\n", r);
    //is_recording_ready = true;
    // debugging at development stage
    #ifdef DEBUG_WAVE
		index = i * REC_BUFFER_LEN;
		p = &mic_data[index];
		memcpy(p, audio_buffer, REC_BUFFER_LEN * sizeof(short));
		i++;
		if(i >= packet_length)
		{
				write_wav("debug/captured_data.wav", packet_length * REC_BUFFER_LEN, mic_data, SAMPLE_RATE);
				printf("save the mic data ok\r\n");
				break;
		}
		printf("the recording loop i = %d is on \r\n", i);
	#endif
	//printf("The recording loop \n");
    if (r < 0)
    {
      if (r != -EAGAIN) {
        fprintf (stderr, "read from audio interface failed (%s), trying to prepare it again...\n", snd_strerror (r));
        if ((err = snd_pcm_prepare (args->device)) < 0) {
          fprintf (stderr, "cannot prepare audio interface for use (%s)\n", snd_strerror (err));
        }
        else
          fprintf (stderr, "Prepare succeed! Device recovers.\n");
      }
      // debugging at development stage
      //else
      //  fprintf (stdout, "EAGAIN when reading from audio: (%s)\n", snd_strerror(r));
    }

	#ifdef DEBUG_RECORD_INTERVAL
		clock_t end = clock();
		double time_spent = (double)(end - begin) * 1000 / CLOCKS_PER_SEC;
		
		printf("[RecordThread]time spend = %lf\n", time_spent);
	#endif	
  }

  return (NULL);
}
