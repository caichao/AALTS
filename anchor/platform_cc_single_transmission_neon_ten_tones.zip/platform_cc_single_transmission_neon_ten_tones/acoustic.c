#include "acoustic.h"
#include "global_variables.h"

int preamble_length;
int symbol_length; 
int guard_interval_length;
int beacon_message_length;
//float buffer[4000] = {0};
//short preambles[2][1920];
//short symbols[2][4][1440];

float *buffer = NULL;
short **preambles = NULL;
short ***symbols = NULL;
//short *guard_interval_samples;
short *beacon_message = NULL;
float *beacon_message_buffer = NULL;

void init()
{
	// variable initialization
	preamble_length = SAMPLING_RATE * PREAMBLE_DURATION;
	symbol_length = SAMPLING_RATE * SYMBOL_DURATION;
	guard_interval_length = SAMPLING_RATE * GUARD_INTERVAL;
	// preamble + symbol + sequence number
	beacon_message_length = preamble_length + guard_interval_length + symbol_length + guard_interval_length + symbol_length;
	
	buffer = (float *) malloc(sizeof(float) * preamble_length);
	if(buffer == NULL) printf("malloc buffer error!!\r\n");
	
	preambles = (short **) malloc(sizeof(short) * PREAMBLE_TYPE);
	if(preambles == NULL) printf("malloc preambles error!!\r\n");
	for(int k = 0; k < PREAMBLE_TYPE; k++)
	{
		preambles[k] = (short *) malloc(sizeof(short) * preamble_length);
	}
	
	symbols = (short ***) malloc(sizeof(short) * PREAMBLE_TYPE);
	if(symbols == NULL) printf("malloc symbols error!!\r\n");
	for(int m = 0; m < SYMBOL_NUMBER; m++)
	{
		symbols[m] = (short **) malloc(sizeof(short) * SYMBOL_NUMBER);
		for(int mm = 0; mm < symbol_length; mm++)
		{
			symbols[m][mm] = (short *) malloc(sizeof(short) * symbol_length);
		}
	}

	
	beacon_message = (short *) malloc(sizeof(short) * beacon_message_length);
	if(beacon_message == NULL) printf("malloc beacon_message error!!\r\n");
	
	beacon_message_buffer = (float *) malloc(sizeof(float) * beacon_message_length);
	if(beacon_message_buffer == NULL) printf("malloc beacon_message buffer error!!\r\n");
	//printf("memory malloc ok\r\n");
	
	// the following code generate preamble without pure tone signal
	//generate_preamble(preambles[UP], UP);
	//generate_preamble(preambles[DOWN], DOWN); 
	
	/*int frequencies[SYMBOL_NUMBER] = {0};
	for(int n = 0; n < SYMBOL_NUMBER; n++)
	{
		frequencies[n] = FMIN + n * SYMBOL_BANDWIDTH;
	}
	for(int i = 0; i < SYMBOL_NUMBER; i++)
	{
		generate_symbol(symbols[UP][i], frequencies[i], UP);
	}
	
	for(int m = 0; m < SYMBOL_NUMBER; m++)
	{
		frequencies[m] = FMAX - m * SYMBOL_BANDWIDTH;
	}			
	for(int j = 0; j < SYMBOL_NUMBER; j++)
	{
		generate_symbol(symbols[DOWN][j], frequencies[j], DOWN);
	}*/
	
	// the following code generate preamble with pure tone signal
	//preamble_generation(preambles[UP], UP);
	//preamble_generation(preambles[DOWN], DOWN); 
	generate_preamble(preambles[UP], UP);
	generate_preamble(preambles[DOWN], DOWN);
	int frequencies[SYMBOL_NUMBER] = {0};
	for(int n = 0; n < SYMBOL_NUMBER; n++)
	{
		frequencies[n] = FMIN + n * SYMBOL_BANDWIDTH;
	}
	
	for(int i = 0; i < SYMBOL_NUMBER; i++)
	{
		symbol_generation(symbols[UP][i], frequencies[i], UP);
	}
	
	for(int m = 0; m < SYMBOL_NUMBER; m++)
	{
		frequencies[m] = FMAX - m * SYMBOL_BANDWIDTH;
	}	
	for(int j = 0; j < SYMBOL_NUMBER; j++)
	{
		symbol_generation(symbols[DOWN][j], frequencies[j], DOWN);
	}	
	
	//-----------------------for debug, to save the preamble and symbol in local files----------------------------------
	#ifdef DEBUG_DATA
		write_txt("preamble[UP].txt", preambles[UP], preamble_length);
		write_txt("symbol[DOWN].txt", symbols[UP][2], symbol_length);
	#endif
	
	#define CHECK_PREAMBLE_SYMBOL
	
	#ifdef CHECK_PREAMBLE_SYMBOL
	//this part has been validated, the symbol and preamble buffer are right
		char temp_file[100] = {'\0'};

		write_short_txt("debug/preamble[UP].txt", preambles[UP], preamble_length);
		write_short_txt("debug/preamble[DOWN].txt", preambles[DOWN], preamble_length);
		
		for(int i = 0; i < SYMBOL_NUMBER; i++)
		{
			memset(temp_file, 0, sizeof(char) * 100);
			sprintf(temp_file, "debug/symbol[UP][%d].txt", i);
			write_short_txt(temp_file, symbols[UP][i], symbol_length);
		}
		for(int i = 0; i < SYMBOL_NUMBER; i++)
		{
			memset(temp_file, 0, sizeof(char) * 100);
			sprintf(temp_file, "debug/symbol[DOWN][%d].txt", i);
			write_short_txt(temp_file, symbols[DOWN][i], symbol_length);
		}		
	#endif
	
	printf("acoustic buffer init ok\r\n");
	
	//#define CHECK_BEACON_ENCODING
	
	#ifdef CHECK_BEACON_ENCODING
	
	char tmp[100] = {0};
	for(int i = 0; i < SYMBOL_NUMBER; i++)
	{
		for(int j = 0; j < SYMBOL_NUMBER; j++)
		{
			memset(tmp, 0 , sizeof(char) * 100);
			sprintf(tmp, "debug/up_preamble_anchorId[%d]_sequence[%d].txt", i, j);
			encoding_beacon_message(i, 0);
			write_short_txt(tmp, beacon_message, beacon_message_length);			
		}
	}
	printf("save beacon message ok\r\n");

	/*for(int i = 0; i < SYMBOL_NUMBER; i++)
	{
		memset(tmp, 0 , sizeof(char) * 100);
		sprintf(tmp, "debug/up_preamble_anchorId[%d]_sequence[%d].txt", 0, i);
		encoding_beacon_message(0, i);
		write_short_txt(tmp, beacon_message, beacon_message_length);
	}*/	
	#endif
}
/**
function: generate intended acoutic buffer for playthread
input: id - anchor ID
	   sequence - the schedule sequence, used to avoid tdoa retrieval error
	   
*/
void encoding_beacon_message(int id, int sequence)
{
	//#define DEBUG_BEACON_MESSAGE
	//printf("[encoded message]: id = %d signal_type = %d \n", id, signal_type);
	//printf("[encode message inner]: id = %d, sequence = %d", id, sequence);
	memset(beacon_message, 0, sizeof(short) * beacon_message_length);
	void *p;
	p = memcpy(beacon_message, preambles[UP], sizeof(short) * preamble_length);
	if(p == NULL)
		perror("copy preamble error");
	short* pp = &beacon_message[preamble_length + guard_interval_length];
	p = memcpy(pp, symbols[DOWN][id], sizeof(short) * symbol_length);
	if(p == NULL)
		perror("copy symbol error");

	pp = &beacon_message[preamble_length + guard_interval_length + symbol_length + guard_interval_length];
	p = memcpy(pp, symbols[DOWN][sequence], sizeof(short) * symbol_length);
	
	multitone_signal(SAMPLING_RATE, TONE_LOW_FMIN, TONE_INTERVAL, NUMBER_OF_TONE, BEACON_DURATION, beacon_message_buffer);
	for(int i = 0; i < beacon_message_length; i++)
	{
		beacon_message_buffer[i] = beacon_message_buffer[i] * (SHORT_MAX) + beacon_message[i];
	}
	float tmp = max(beacon_message_buffer, beacon_message_length);
	for(int j = 0; j < beacon_message_length; j++)
	{
		beacon_message_buffer[j] = beacon_message_buffer[j] / tmp;
		beacon_message[j] = (short)(beacon_message_buffer[j] * SHORT_MAX);
	}
	
	if(p == NULL)
		perror("copy sequence error");	
	
	// we insert much longer pure tones here
	
	#ifdef DEBUG_BEACON_MESSAGE
	char tmp[100] = {0};
	sprintf(tmp, "debug/beacon_message_id[%d]_sequence[%d].txt", id, sequence);
	write_short_txt(tmp, beacon_message, beacon_message_length);
	#endif 
}

/**
deprecated method
function: generate intended acoutic buffer for playthread
input: id - anchor ID
	   signal_type - define waveform UP for up preamble and DOWN for down preamble
*/
/*void encoding_beacon_message(int id, int signal_type)
{
	//printf("[encoded message]: id = %d signal_type = %d \n", id, signal_type);
	memset(beacon_message, 0, sizeof(short) * beacon_message_length);
	void *p;
	p = memcpy(beacon_message, preambles[signal_type], sizeof(short) * preamble_length);
	if(p == NULL)
		perror("copy preamble error");
	short* pp = &beacon_message[preamble_length + guard_interval_length];
	p = memcpy(pp, symbols[signal_type][id], sizeof(short) * symbol_length);
	if(p == NULL)
		perror("copy symbol error");	
}*/
/**
Deprecated method for generating symbols
*/
void generate_preamble(short *sample, int type)
{
	memset(buffer, 0, sizeof(float) * preamble_length);
	if(type == UP)
	{
		for(int i = 0; i < preamble_length; i++)
		{
			buffer[i] = cos(2 * PI * FMIN * i / SAMPLING_RATE + PI * PREAMBLE_BANDWIDTH / PREAMBLE_DURATION * i * i / SAMPLING_RATE / SAMPLING_RATE);
		}
		waveform_reshape(buffer, 0, preamble_length);
		for(int i = 0; i < preamble_length; i++)
		{
			sample[i] = (short)(SHORT_MAX * buffer[i]);
		}	
	}
	else if(type == DOWN)
	{
		for(int i = 0; i < preamble_length; i++)
		{
			buffer[i] = cos(2 * PI * FMAX * i / SAMPLING_RATE - PI * PREAMBLE_BANDWIDTH / PREAMBLE_DURATION * i * i / SAMPLING_RATE / SAMPLING_RATE);
		}
		waveform_reshape(buffer, 0, preamble_length);
		for(int i = 0; i < preamble_length; i++)
		{
			sample[i] = (short)(SHORT_MAX * buffer[i]);
		}		
	}
}
/**
deprecated methods for generating symbols
*/
void generate_symbol(short* sample, int f, int type)
{
	memset(buffer, 0, sizeof(float) * preamble_length);
	if(type == UP)
	{
		for(int i = 0; i < preamble_length; i++)
		{
			buffer[i] = cos(2 * PI * f * i / SAMPLING_RATE + PI * SYMBOL_BANDWIDTH / SYMBOL_DURATION * i * i / SAMPLING_RATE / SAMPLING_RATE);
		}
		waveform_reshape(buffer, 0, preamble_length);
		for(int i = 0; i < preamble_length; i++)
		{
			sample[i] = SHORT_MAX * buffer[i];
		}		
	}
	else if(type == DOWN)
	{
		for(int i = 0; i < preamble_length; i++)
		{
			buffer[i] = cos(2 * PI * f * i / SAMPLING_RATE - PI * SYMBOL_BANDWIDTH / SYMBOL_DURATION * i * i / SAMPLING_RATE / SAMPLING_RATE);
		}
		waveform_reshape(buffer, 0, preamble_length);
		for(int i = 0; i < preamble_length; i++)
		{
			sample[i] = SHORT_MAX * buffer[i];
		}		
	}	
}

void preamble_generation(short *sample, int type)
{
	memset(buffer, 0, sizeof(float) * preamble_length);
	float* tmp = (float *)malloc(sizeof(float) * preamble_length);
	memset(tmp, 0, preamble_length);
	if(type == UP)
	{
		chirp_signal(SAMPLING_RATE, FMIN, PREAMBLE_DURATION, PREAMBLE_BANDWIDTH, buffer, UP); // generate chirp signal
		multitone_signal(SAMPLING_RATE, TONE_LOW_FMIN, TONE_INTERVAL, NUMBER_OF_TONE, PREAMBLE_DURATION, tmp); // generate tone signal
		for(int i = 0; i < preamble_length; i++)
			tmp[i] += buffer[i];
		
		signal_normalization(tmp, preamble_length);
		waveform_reshape(tmp, 0, preamble_length);
		for(int i = 0; i < preamble_length; i++)
		{
			sample[i] = (short)(SHORT_MAX * tmp[i]);
		}		
	}
	else if(type == DOWN)
	{
		chirp_signal(SAMPLING_RATE, FMAX, PREAMBLE_DURATION, PREAMBLE_BANDWIDTH, buffer, DOWN); // generate chirp signal
		multitone_signal(SAMPLING_RATE, TONE_LOW_FMIN, TONE_INTERVAL, NUMBER_OF_TONE, PREAMBLE_DURATION, tmp); // generate tone signal
		for(int i = 0; i < preamble_length; i++)
			tmp[i] += buffer[i];
		
		signal_normalization(tmp, preamble_length);
		waveform_reshape(tmp, 0, preamble_length);
		for(int i = 0; i < preamble_length; i++)
		{
			sample[i] = (short)(SHORT_MAX * tmp[i]);
		}		
	}	
	free(tmp);
}

void symbol_generation(short* sample, int f, int type)
{
	memset(buffer, 0, sizeof(float) * symbol_length);
	if(type == UP)
	{
		chirp_signal(SAMPLING_RATE, f, SYMBOL_DURATION, SYMBOL_BANDWIDTH, buffer, UP); // generate chirp signal
		signal_normalization(buffer, symbol_length);
		waveform_reshape(buffer, 0, symbol_length);
		for(int i = 0; i < symbol_length; i++)
		{
			sample[i] = (short)(SHORT_MAX * buffer[i]);
		}		
	}
	else if(type == DOWN)
	{
		chirp_signal(SAMPLING_RATE, f, SYMBOL_DURATION, SYMBOL_BANDWIDTH, buffer, DOWN); // generate chirp signal
		signal_normalization(buffer, symbol_length);
		waveform_reshape(buffer, 0, symbol_length);
		for(int i = 0; i < symbol_length; i++)
		{
			sample[i] = (short)(SHORT_MAX * buffer[i]);
		}			
	}	
}

/**
function: generate chirp signal in float format
input: 
	fs: sampling rate in Hz
	fmin: initial frequency in Hz
	t: duration of the chirp_signal in seconds
	b: bandwidth in Hz
	type: UP or DOWN, define the chirp shape
output:
	s: output chirp signal in normalized float format 
*/
void chirp_signal(int fs, int fmin, float t, int b, float* s, int type)
{
	int n = fs * t;
	if(type == UP)
	{
		for(int i = 0; i < n; i++)
		{
			s[i] = cos(2 * PI * fmin * i / fs + PI * b / t * i * i / fs / fs);
		}
	}
	else if(type == DOWN)
	{
		for(int i = 0; i < n; i++)
		{
			s[i] = cos(2 * PI * fmin * i / fs - PI * b / t * i * i / fs / fs);
		}		
	}
}
/**
function: generate multiple pure tone signal
input:
	fs: sampling rate in Hz
	fmin: initial frequency in Hz
	frequency_interval: interval between each tone signal in Hz
	duration: duration of the tone signal in seconds 
output:
	s: sample in normalized float format
*/
void multitone_signal(int fs, int fmin, int frequency_interval, int number_of_tone, float duration, float* s)
{
	int n = fs * duration;
	memset(s, 0, n);
	//float* tmp = (float *)malloc(sizeof(float) * n);
	for(int i = 0; i < number_of_tone; i++)
	{
		for(int j = 0; j < n; j++)
		{
			s[j] += cos(2 * PI * (fmin + i * frequency_interval)* j / fs);
		}
	}
	
	// a normalization process
	signal_normalization(s, n);
}

void signal_normalization(float* s, int n)
{
	float m = max(s, n);
	for(int i = 0; i < n; i++)
	{
		s[i] = s[i]/m;
	}
}

float max(float* s, int n)
{
	float max_value = -32768;
	for(int i = 0; i < n; i++)
	{
		if(s[i] > max_value)
			max_value = s[i];
	}
	return max_value;
}
void waveform_reshape(float* samples, int start_index, int end_index)
{
    int k = 100;

    for(int i = 0; i < k; i++){
        samples[i + start_index] = samples[i + start_index] * (i + 1) / k;
        samples[end_index - 1 - i] = samples[end_index - 1 - i] * (i + 1) / k;
    }	
}