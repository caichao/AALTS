#ifndef WRITE_WAV_H
#define WRITE_WAV_H

extern void write_wav(char * filename, unsigned long num_samples, short int * data, unsigned int sample_rate);
extern void write_float_txt(const char* file_name, float* array, int len);
extern void write_short_txt(const char* file_name, short* array, int len);
#endif


