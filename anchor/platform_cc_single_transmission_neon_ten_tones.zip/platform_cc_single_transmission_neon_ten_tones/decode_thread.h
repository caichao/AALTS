#ifndef DECODE_THREAD_H
#define DECODE_THREAD_H

#include "basic_headers.h"
#include "record_thread.h"
#include "fft.h"
#include "write_wav.h"
#include "global_variables.h"

#define THRESHOLD	5

extern void *DecodeThread();

typedef struct IndexRecord
{
	bool is_splicing_needed;
	int preamble_index;
	long int looper_counter;
}IndexRecord;

typedef struct CapturePreambleRecord
{
	bool is_new_captured;
	int anchorId;
	int sequenceId;
	int preamble_index;
	int looper_counter;
}CapturePreambleRecord;

typedef struct RefineParameter
{
	int threshold;
	int windows;
	int scale_mean_promissing;
	int naive_threshold;
	float threshold_percentage;
}RefineParameter;

void debug_concated_data(int i);
int decoding_symbol_sequence(short* capture_data, int index);
int anchorId_decoding_directly(short* capture_data, int start_index, int type);
int anchorId_decoding_debug(int count, short* capture_data, int preamble_start_index, int type);
void debug_data(int i);
void debug_parameters(int i, int index, float max, int anchorID);
float peak_refinement(int* index, float* correlation_result, int length, RefineParameter refine_parameter);
void pre_processing(float* filled_buffer, int filled_buffer_length, short* fresh_data, int fresh_data_length);
void peak_find(float* result, int n, int* index, float* max);
void magnitude_calculation(float* complex, float* real_magnitude, int length);
void parameter_initialization();
void preamble_symbol_fft_storage_initialization();
void xcorr(float* capture_data, float* reference_data, float* result, int length);
int anchorId_decoding(short* capture_data, int preamble_start_index, int type);
float mean_cal(float* result, int n);
float average_cal(float* result, int start, int end);
#endif

