#ifndef SCHEDULE_THREAD_H
#define SCHEDULE_THREAD_H

#include "basic_headers.h"
#include "json_wraper.h"
#include "upload_thread.h"
#include "acoustic.h"

#define MESSAGE_BUFFER_LEN	256

#define UP  0
#define DOWN  1 

extern void *ScheduleThread();

#endif



