#include "schedule_thread.h"
#include "global_variables.h"
#include "acoustic.h"

//#define DEBUG_SCHEDULE

int port;
void *ScheduleThread()
{
	int port = g_parameter.schedule_port;
	int id = g_parameter.anchorId;
	#ifdef DEBUG_SCHEDULE
	char debug_txt[100] = {0};
	#endif

    int sock;                         /* Socket */
    struct sockaddr_in broadcastAddr; /* Broadcast Address */
    unsigned short broadcastPort;     /* Port */
    char recvString[MESSAGE_BUFFER_LEN]; /* Buffer for received string */
    int recvStringLen;                /* Length of received string */

    broadcastPort = port;   /* First arg: broadcast port */

    /* Create a best-effort datagram socket using UDP */
    if ((sock = socket(PF_INET, SOCK_DGRAM, IPPROTO_UDP)) < 0)
        perror("socket() failed");

    /* Construct bind structure */
    memset(&broadcastAddr, 0, sizeof(broadcastAddr));   /* Zero out structure */
    broadcastAddr.sin_family = AF_INET;                 /* Internet address family */
    broadcastAddr.sin_addr.s_addr = htonl(INADDR_ANY);  /* Any incoming interface */
    broadcastAddr.sin_port = htons(broadcastPort);      /* Broadcast port */

    /* Bind to the broadcast port */
    if (bind(sock, (struct sockaddr *) &broadcastAddr, sizeof(broadcastAddr)) < 0)
        perror("bind() failed");

	//char type[10] = {0};
	
	printf("[schedule thread] is ready \r\n");
	int sequenceId = -1;
	while(1)
	{
		/* Receive a single datagram from the server */
		if ((recvStringLen = recvfrom(sock, recvString, MESSAGE_BUFFER_LEN, 0, NULL, 0)) < 0)
			perror("recvfrom() failed \n");

		recvString[recvStringLen] = '\0';
		#ifdef DEBUG_SCHEDULE
			printf("Received: %s\n", recvString);    /* Print the received string */	
		#endif
		
		if(true == is_my_timeslot(id, recvString, &sequenceId))
		{
			//printf("I am in \n");
			#ifdef DEBUG_SCHEDULE
			memset(debug_txt, 0, 100 * sizeof(char));
			#endif
			
			#ifdef ENABLE_TRANSMISSION
				//printf("transmit_beacon_message\n");
				encoding_beacon_message(id, sequenceId);
				transmit_beacon_message();
			#endif
		}	
		
		// clear the buffer 
		memset(recvString, 0, sizeof(char) * MESSAGE_BUFFER_LEN);
	}

    
    close(sock);
}