#include "decode_thread.h"
#include "upload_thread.h"
#include "json_wraper.h"
#include "fifo.h"
#include <math.h>

//Ne10
#include "NE10_types.h"
#include "NE10_physics.h"
#include "NE10_math.h"
#include "NE10_macros.h"
#include "NE10_init.h"
#include "NE10_imgproc.h"
#include "NE10_dsp.h"
#include "NE10.h"

//raspi_gpu_fft
#include "gpu_fft.h"
#include "mailbox.h"

#define jobs 1
int mb;
struct GPU_FFT_COMPLEX *base;
struct GPU_FFT *fft;
struct GPU_FFT *fft_12;
struct GPU_FFT *ifft_12;
struct GPU_FFT *ifft;
float temp1[16384];
float temp2[8192];


short process_buffer[REC_BUFFER_LEN + REC_BUFFER_LEN / 2];
short last_process_buffer[REC_BUFFER_LEN/2];
short rectrieved_buffer[REC_BUFFER_LEN];

float normalize_process_buffer[REC_BUFFER_LEN + REC_BUFFER_LEN / 2];
//float **normalize_preambles = NULL;
//float ***normalize_symbols = NULL;

int process_buffer_length = REC_BUFFER_LEN + REC_BUFFER_LEN / 2;
float  a[8192],b[8192],c[8192],d[8192],e[8192],f[8192],g[8192],h[8192];//�о������������������û������
float* padded_captured_data_for_preamble = NULL;
float* padded_captured_data_for_symbol = NULL;
float* padded_reference_data = NULL;
float* result_preamble_complex_data = NULL;
float* result_preamble_magnitude = NULL;
float* result_symbol_complex_data = NULL;
float* result_symbol_magnitude = NULL;
short* concated_buffer = NULL;

float** preamble_fft_storage = NULL;
float*** symbol_fft_storage = NULL;

RefineParameter refine_parameter;

// N denote the number we perform FFT and correlation
int N = 0;

//#define DEBUG_CHECK_FIFO

//#define DEBUG_DECODING

//#define DEBUG_TIME_SPEND
void *DecodeThread()
{
	//parameter_initialization();
	short *p = NULL;
	//int i = 0;
	int threshold = g_parameter.detection_threshold;
	int anchorId = g_parameter.anchorId;
	//int timestamp_counter = 0;
	CaptureBeaconMessage capture_beacon_message;
	
	refine_parameter.threshold = threshold;
	refine_parameter.windows = 200;
	refine_parameter.threshold_percentage = 0.8;
	refine_parameter.scale_mean_promissing = 2;
	refine_parameter.naive_threshold = 20;
	

	#ifdef DEBUG_DECODING
		long int effective_up_loop_counter = 0;
	#endif 
	long int looper_counter = 0;
	IndexRecord up_record;
	up_record.is_splicing_needed = false;
  mb = mbox_open();
  gpu_fft_prepare(mb, 13, 0, jobs, &fft);
  gpu_fft_prepare(mb, 12, 0, jobs, &fft_12);
    gpu_fft_prepare(mb, 12,1, jobs, &ifft_12);
  gpu_fft_prepare(mb, 13, 1, jobs, &ifft);	
 
	parameter_initialization();
	preamble_symbol_fft_storage_initialization();
	printf("decode thread is ready! [threshold = %d]\n", threshold);
  // Initialise Ne10, using hardware auto-detection to set library function pointers
  if (ne10_init()!= NE10_OK)                       //!!initial should be in the main function ??                question
  { 
      fprintf(stderr, "Failed to initialise Ne10.\n");
      return 1;
  }

	#ifdef DEBUG
		char tmp_file[100] = {0};
	#endif
	
	#ifdef DEBUG_WAVE
		while(1);
	#endif
	
	/**
	1. if the preamble is detected twice - handled
	2. if the preamble exist in the last buffer and the symbol appears in the current buffer, use continue
	*/
	
	/**
	Debug information:
	1. when the environment is quite, the max correlation peak is below 1, about 0.23, when a clap noise exist, the correlation value can be up to 60
	2. when intended chirp signal is transmitted, the correlation value can be up to 40, but the correlation peak of other orthogonal channel can also be up to 20
	3. when use 200 samples ahead of the peaks, the new peak in a quite environment is 0 or nan, with clap noise, the peak reaches to 3
	4. when use 200 samples ahead of the peaks, if intended acoustic wave is transmitted, then the correlation peak can be 20
	
	5. a valid peak is detected if the following conditions are satisfied:
		(1) the correlation peak is beyond a certain threshold more than 20
		(2) the the correlation peak should be larger than the mean value, at least 10 times
		Exceptional case:
			(1)sometimes, when the peaks ahead have few samples, may only contain 20 samples, way much less than the windows W, in this case, the magnitude will be magnified
	
	6. multipath should be handled as it really happens when the LOS signal with lower amplitude appears ahead of the maximum peak
	7. It has been confirmed that, do not use max * max can cope with near-far effect
	8. If the index of the preamble appears in the much later part of the buffer, we should wait and need to use the samples in the next cycle
	--------------------------------------------------------------------------------------------
	the above debug information are when the threshold are based on ratio = max / mean 
	
	the following debug information are based on ratio = max * max / mean 
	 max * max / mean is not available
	 
	--------------------------------------------------------------------------------------------
	[preamble + symbol + sequence] decoding strategy
	1. if all of them are fall into the current buffer, decoding them directly
	2. if the beacon message are divided by two parts, we concate the BUFFER data of two adjacent sampling into a large buffer to decode them 
	3. TODO: we should consider whether the preamble is divided by two adjacent sampling
	*/
	
	int decoded_id = 0;
	int decoded_sequence = 0;
	bool is_valid_data_captured = 0;
	while(1)
	{
		//#define DEBUG_TIME_SPEND
		is_recording_ready(); // wait for the buffer update
		looper_counter++;
		//printf("looper_counter = %ld\n", looper_counter);

		
		memcpy(process_buffer, last_process_buffer, sizeof(short) * REC_BUFFER_LEN / 2); // use the last half buffer data
		
		p = &process_buffer[REC_BUFFER_LEN/2];		
		pop(rectrieved_buffer);		
		
		memcpy(p, rectrieved_buffer, sizeof(short) * REC_BUFFER_LEN); // filling the current fresh data
		
		p = &rectrieved_buffer[REC_BUFFER_LEN/2];
		memcpy(last_process_buffer, p, sizeof(short) * REC_BUFFER_LEN/2);
		
		#ifdef DEBUG_CHECK_FIFO
		static short wave[REC_BUFFER_LEN * 50] = {0};
		static int i = 0;
		pop(rectrieved_buffer);
		memcpy(wave + i * REC_BUFFER_LEN, rectrieved_buffer, REC_BUFFER_LEN * sizeof(short) );
		i++;
		if(i == 50)
		{
			write_wav("debug/check_fifo.wav", REC_BUFFER_LEN * 50, wave, SAMPLE_RATE);
			printf("save wave file ok!\n");
			break;
		}
		#endif 
		// TODO process logic, perform correlation, peak detection, etc

		#ifdef DEBUG_TIME_SPEND
			clock_t begin = clock();
		#endif 
		// ***************************** Detection for up preamble and up symbol *********************************************
		if(up_record.is_splicing_needed == true)
		{
			up_record.is_splicing_needed = false;
			int left_buffer_length = beacon_message_length - (process_buffer_length - up_record.preamble_index);
			short *p = &process_buffer[REC_BUFFER_LEN/2]; // new samples
			memcpy(concated_buffer + (process_buffer_length - up_record.preamble_index), p, left_buffer_length * sizeof(short));
			
			int start = preamble_length + guard_interval_length;
			// here we need to decode the anchor id directly, no index shift any more
			
			decoded_id = decoding_symbol_sequence(concated_buffer, start);
			printf("[waited]Decoded anchor ID = %d\n", decoded_id);
			
			start = start + symbol_length + guard_interval_length;
			decoded_sequence = decoding_symbol_sequence(concated_buffer, start);
			printf("[waited]Decoded sequence = %d\n", decoded_sequence); 
			
			is_valid_data_captured = true;
			
			#ifdef DEBUG_DECODING
				static int i = 100;
				debug_concated_data(i);
				debug_parameters(i, up_record.preamble_index, 0, decoded_id);	
				i++;
			#endif
		}
		else
		{
			int up_index;
			float up_max;
			pre_processing(padded_captured_data_for_preamble, N * 2, process_buffer, process_buffer_length);
			xcorr(padded_captured_data_for_preamble, preamble_fft_storage[UP], result_preamble_complex_data, N * 2);
			magnitude_calculation(result_preamble_complex_data, result_preamble_magnitude, 2*N);
			
			up_max = peak_refinement(&up_index, result_preamble_magnitude, N, refine_parameter);
			//printf("[up max] = %f at [up index] = %d  \n", up_max, up_index);
			if(up_max > refine_parameter.threshold)
			{
				printf("[up max] = %f at [up index] = %d  \n", up_max, up_index);
				int end_of_beacon_message = up_index + beacon_message_length;
				//if((end_of_beacon_message - process_buffer_length) < 0 || (process_buffer_length - end_of_beacon_message) > (symbol_length / 2))
				if((end_of_beacon_message - process_buffer_length) < 0)
				{
					int start_index = up_index + preamble_length + guard_interval_length;
					//id = decoding_symbol_sequence(process_buffer, start_index);
					decoded_id = decoding_symbol_sequence(process_buffer, start_index);
					printf("[+++]Decoded anchor ID = %d\n", decoded_id);
					start_index += symbol_length + guard_interval_length;
					decoded_sequence = decoding_symbol_sequence(process_buffer, start_index);
					printf("[+++]Decoded sequence = %d\n", decoded_sequence);
					is_valid_data_captured = true;
					#ifdef DEBUG_DECODING
						debug_data(effective_up_loop_counter);
						debug_parameters(effective_up_loop_counter, up_index, up_max, id);
						effective_up_loop_counter++;
					#endif 		
					/*if(decoded_id != anchorId)
					{
						debug_data(1000);
						debug_parameters(1000, up_index, up_max, decoded_id);	
						printf("find out abnormal data \n");
						while(1);
					}*/
				}
				else // open lock and use the next buffer sample to decode the anchor ID
				{
					up_record.is_splicing_needed = true;
					memset(concated_buffer, 0, beacon_message_length * sizeof(short));
					int length = process_buffer_length - up_index;
					short* p = &process_buffer[up_index];
					memcpy(concated_buffer, p, length * sizeof(short));	
				}
				
				up_record.preamble_index = up_index;
				up_record.looper_counter = looper_counter;
			}
		}
		/*if(timestamp_counter == 2 && up_record.is_splicing_needed == false)
		{
			printf("first anchorId = %d ---- second anchorId = %d \n", up_record.first_anchorId, up_record.second_anchorId);
			int tdoa = up_record.second_index + looper_counter * REC_BUFFER_LEN - up_record.first_anchorId;
			printf("tdoa = %d with time = %.2f ms\n", tdoa, tdoa * 1000.0 / SAMPLE_RATE);
			timestamp_counter = 0;
			looper_counter = 0;
			if((anchorId == up_record.first_anchorId || anchorId == up_record.second_anchorId) && (up_record.first_anchorId != up_record.second_anchorId))
			{
				upload_timestamp(up_record.first_anchorId, up_record.second_anchorId, tdoa);
			}
		}*/
		
		if(is_valid_data_captured == true)
		{
			is_valid_data_captured = false;
			
			capture_beacon_message.self_anchorId = anchorId;
			capture_beacon_message.captured_anchorId = decoded_id;
			capture_beacon_message.captured_sequence = decoded_sequence;
			capture_beacon_message.preamble_index = up_record.preamble_index;
			capture_beacon_message.looper_counter = up_record.looper_counter;
			
			upload_capture_beacon_message(capture_beacon_message);
			printf("Beacon message uploaded ################################ \r\n");
			#ifdef BEEPBEEP
			// test pair-wised ranging performance
			
			
			#endif
		}
	

		#ifdef DEBUG_THRESHOLD
 		if(up_max != 0)
		{
			printf("[up max] = %f at [up index] = %d  \n", up_max, up_index);
			char file_name[100] = {0};
			memset(file_name, 0, sizeof(char)*100);
			sprintf(file_name, "debug/correlation_up_%d.txt", effective_up_loop_counter);
			write_float_txt(file_name, result_preamble_magnitude, N);
				
			memset(file_name, 0, sizeof(char)*100);
			sprintf(file_name, "debug/correlation_up_buffer_%d.txt", effective_up_loop_counter);
			write_short_txt(file_name, process_buffer, process_buffer_length);
				
			printf("save up correlation results ok!\n");
			effective_up_loop_counter++;
		}
		#endif


		/*
  		if(timestamp_counter == 2)
		{
			// in our concurrent transmission case, the up and down preamble appears almost at the same time			
			upload_timestamp(anchorId, down_index - up_index);
			printf("Upload timestamps by anchorId = %d with TDOA = [%d]\n", anchorId, down_index - up_index);
		}*/
	
		
 		#ifdef DEBUG_TIME_SPEND
		clock_t end = clock();
		double time_spent = (double)(end - begin) * 1000 / CLOCKS_PER_SEC;
		
		printf("time spend = %lf\n", time_spent);
		#endif 	
	}
	
}

/**
function: used to log the buffer data to the local txt file 
*/
void debug_concated_data(int i)
{
	char file_name[100] = {0};
	memset(file_name, 0, sizeof(char)*100);
	sprintf(file_name, "debug/correlation_value_%d.txt", i);
	write_float_txt(file_name, result_preamble_magnitude, N);
				
	memset(file_name, 0, sizeof(char)*100);
	sprintf(file_name, "debug/buffer_value_%d.txt", i);
	write_short_txt(file_name, concated_buffer, beacon_message_length);
				
	printf("save data ok!\n");
}

/**
function: used to log the buffer data to the local txt file 
*/
void debug_data(int i)
{
	char file_name[100] = {0};
	memset(file_name, 0, sizeof(char)*100);
	sprintf(file_name, "debug/correlation_value_%d.txt", i);
	write_float_txt(file_name, result_preamble_magnitude, N);
				
	memset(file_name, 0, sizeof(char)*100);
	sprintf(file_name, "debug/buffer_value_%d.txt", i);
	write_short_txt(file_name, process_buffer, process_buffer_length);
				
	printf("save data ok!\n");
}
/**
function: save the parameters to the local txt
*/
void debug_parameters(int i, int index, float max, int anchorID)
{
	char file_name[100] = {0};
	memset(file_name, 0, sizeof(char)*100);
	sprintf(file_name, "debug/parameters_%d.txt", i);
	
	FILE * fp;
    fp = fopen (file_name, "w+");
    fprintf(fp, "%d\n", index);
	fprintf(fp, "%f\n", max);
	fprintf(fp, "%d\n", anchorID);
    fclose(fp);
				
	printf("save parameter ok!\n");
}
/**
function: used to filter the wrong max peak value
input: 
		correlation_result - correlation result 
		length - length of buffer that store the correlation result
		RefineParameter - parameters that used to filter the correlation results include
				naive_threshold -- filter samples with low value
				window -- windows length that extracted ahead of the index corresponding to the maximum value
				threshold_percentage -- used to filter the multipath effect
				scale_mean_promissing -- used to handle exception 1
output:
		*index - index value corresponding to the maximum peak 
		
return: maximum peak value after refinement
*/
float peak_refinement(int* index, float* correlation_result, int length, RefineParameter refine_parameter)
{
	float max_peak;
	
	peak_find(correlation_result, length, index, &max_peak);
	#ifdef ENABLE_SQUARE
		max_peak = max_peak * max_peak;
	#endif
	
	float mean = average_cal(correlation_result, *index - refine_parameter.windows, *index);
	
	if(mean == 0 || max_peak < refine_parameter.naive_threshold) // captured raw data threshold is not enough 
	{
		max_peak = 0;
		return max_peak;
	}
		
	int valid_length = (*index - refine_parameter.windows) < 0 ? *index : refine_parameter.windows; // in case there are few samples ahead
		
	if(max_peak > refine_parameter.scale_mean_promissing * mean) // handle exception 1
	{
		max_peak = max_peak / mean * refine_parameter.windows / valid_length;
	}
	else
	{
		max_peak = 0;
	}
		
	if(isnan(max_peak))
	{
		max_peak = 0;
	}		
	return max_peak;
}

void parameter_initialization()
{
	N = process_buffer_length + preamble_length;
	N = (int)(log(N)/log(2)) + 1;
	N = pow(2, N);
	// This N is the FFT size, but if we want to feed it in CDFT function, we need a buffer that is twice of it
	// since the CDFT function need to compute the real part as well as the imaginary part 
	//printf("N = %d", N);
	
	padded_captured_data_for_preamble = (float *) malloc(sizeof(float) * N * 2);
	if(padded_captured_data_for_preamble == NULL) perror(" malloc capture buffer error\n");
	padded_captured_data_for_symbol = (float *) malloc(sizeof(float) * N);
	if(padded_captured_data_for_symbol == NULL) perror(" malloc capture buffer error\n");
	
	padded_reference_data = (float *) malloc(sizeof(float) * N);
	if(padded_reference_data == NULL) perror(" malloc reference buffer error\n");
	result_preamble_complex_data = (float *) malloc(sizeof(float) * N * 2);
	if(result_preamble_complex_data == NULL) perror(" malloc result complex buffer error\n");
	result_preamble_magnitude = (float *) malloc(sizeof(float) * N);
	if(result_preamble_magnitude == NULL) perror(" malloc result magnitude buffer error\n");
	
	result_symbol_complex_data = (float *) malloc(sizeof(float) * N);
	if(result_symbol_complex_data == NULL) perror(" malloc result symbol complex buffer error\n");
	result_symbol_magnitude = (float *) malloc(sizeof(float) * N / 2);
	if(result_symbol_magnitude == NULL) perror(" malloc result symbol magnitude buffer error\n");
	
	concated_buffer = (short *) malloc(sizeof(short) * beacon_message_length);
	if(concated_buffer == NULL) perror("malloc concated buffer error \n");
}

void preamble_symbol_fft_storage_initialization()
{ 
	preamble_fft_storage = (float **) malloc(sizeof(float) * PREAMBLE_TYPE);
	int i = 0;
	for(i = 0; i < PREAMBLE_TYPE; i++)
	{
		preamble_fft_storage[i] = (float *) malloc(sizeof(float) * N * 2);
	}
	
	symbol_fft_storage = (float ***) malloc(sizeof(float) * PREAMBLE_TYPE);
	int j = 0;
	for(j = 0; j < PREAMBLE_TYPE; j++)
	{
		symbol_fft_storage[j] = (float **) malloc(sizeof(float) * SYMBOL_NUMBER);
		for(i = 0; i < SYMBOL_NUMBER; i++)
		{
			symbol_fft_storage[j][i] = (float*) malloc(sizeof(float) * N);
		}
	} // util here, there is no segment fault exception 


	int k = 0;
	for( k = 0; k < PREAMBLE_TYPE; k++)
	{
		for(int m = 0; m < preamble_length; m++)
		{
			preamble_fft_storage[k][m*2] = preambles[k][m] / 32768.0;
		}
//      for(j = 0; j <16384; j++)
//			{
//			  temp1[j]=	preamble_fft_storage[k][j];
//			}
//      fftt(13,1,temp1,temp1);
//      for(j = 0; j <16384; j++)
//			{
//			  preamble_fft_storage[k][j]=	temp1[j];
//			}
    memcpy(temp1,preamble_fft_storage[k], sizeof(float) * 16384);
     fftt(13,1,temp1,temp1);
    memcpy(preamble_fft_storage[k],temp1, sizeof(float) * 16384); 
//		cdft(2*N, -1, preamble_fft_storage[k]);
	} // until here, there is no segment fault exception 
	
	for( k = 0; k < PREAMBLE_TYPE; k++)
	{
		for(i = 0; i < SYMBOL_NUMBER; i++)
		{
			for(j = 0; j < symbol_length; j++)
			{
				symbol_fft_storage[k][i][j*2] = symbols[k][i][j] / 32768.0;
			}
    memcpy(temp2,symbol_fft_storage[k][i], sizeof(float) * 8192);
     fftt(12,1,temp2,temp2);
   memcpy(symbol_fft_storage[k][i],temp2, sizeof(float) * 8192); 
//			cdft(N, -1, symbol_fft_storage[k][i]);
		}
	}/* debug ok  */ 
}

/*void preamble_symbol_normalization()
{
	normalize_preambles = (float **) malloc(sizeof(float *) * PREAMBLE_TYPE);
	if(normalize_preambles == NULL) printf("malloc preambles error!!\r\n");
	for(int k = 0; k < PREAMBLE_TYPE; k++)
	{
		normalize_preambles[k] = (float *) malloc(sizeof(float *) * preamble_length);
	}	
	
	normalize_symbols = (float ***) malloc(sizeof(float *) * PREAMBLE_TYPE);
	if(normalize_symbols == NULL) printf("malloc symbols error!!\r\n");
	for(int m = 0; m < SYMBOL_NUMBER; m++)
	{
		normalize_symbols[m] = (float **) malloc(sizeof(float *) * SYMBOL_NUMBER);
		for(int mm = 0; mm < symbol_length; mm++)
		{
			normalize_symbols[m][mm] = (float *) malloc(sizeof(float *) * symbol_length);
		}
	}
	printf("[DecodThread] reference data normalization ok!\n");
}*/
void pre_processing(float* filled_buffer, int filled_buffer_length, short* fresh_data, int fresh_data_length)
{
	memset(filled_buffer, 0, sizeof(float) * filled_buffer_length);
	//memset(padded_captured_data_for_symbol, 0, sizeof(float) * N);
	for(int i = 0; i < fresh_data_length; i++)
	{
		filled_buffer[2*i] = (float)(fresh_data[i]) / 32768.0;
		//padded_captured_data_for_symbol[i] = padded_captured_data_for_preamble[i];
	}	
	//memcpy(padded_captured_data_for_symbol, padded_captured_data_for_preamble, sizeof(float) * fresh_data_length);
	
	#ifdef DEBUG_DATA
		write_float_txt("debug/filled_buffer.txt", filled_buffer, filled_buffer_length);
		//write_float_txt("debug/padded_captured_data_for_symbol.txt", padded_captured_data_for_symbol, N/2);
	#endif
   fftt(13,1,filled_buffer,filled_buffer);
//	cdft(2*N, -1, filled_buffer);
	cdft(N/2, -1, padded_captured_data_for_symbol);
	
	#ifdef DEBUG_DATA
		write_float_txt("debug/filled_buffer_after_fft.txt", filled_buffer, filled_buffer_length);
		//write_float_txt("debug/padded_captured_data_for_symbol_after_fft.txt", padded_captured_data_for_symbol, N/2);
	#endif	
	/*memset(padded_reference_data, 0, sizeof(float) * N);
	for(int j = 0; j < reference_data_length; j++)
	{
		padded_reference_data[j] = reference_data[j] / 32768;
	}*/
	//printf("[DecodThread] data normalization ok!\n");
}

int decoding_symbol_sequence(short* capture_data, int start_index)
{
	// first extract the samples corresponding to symbol region
	memset(padded_captured_data_for_symbol, 0, N * sizeof(float));
	for(int i = 0; i < symbol_length; i++)
	{
		padded_captured_data_for_symbol[2 * i] = capture_data[i + start_index] / 32768.0;
	}
   fftt(12,1,padded_captured_data_for_symbol,padded_captured_data_for_symbol);  
//	cdft(N, -1, padded_captured_data_for_symbol);
	
	float anchors[SYMBOL_NUMBER] = {0};
	int index = 0;
	for(int i = 0; i < SYMBOL_NUMBER; i++)
	{
		xcorr(padded_captured_data_for_symbol, symbol_fft_storage[DOWN][i], result_symbol_complex_data, N);
		magnitude_calculation(result_symbol_complex_data, result_symbol_magnitude, N);
		peak_find(result_symbol_magnitude, N/2, &index, &anchors[i]); // store the maximum correlation results
		anchors[i] = anchors[i] / mean_cal(result_symbol_magnitude, N/2); // ratio between the maximum value and the average
		
	}
	
	float max = anchors[SYMBOL_NUMBER - 1];
	index = SYMBOL_NUMBER - 1;
	for(int i = 0; i < SYMBOL_NUMBER - 1; i++)
	{
		if(anchors[i] > max)
		{
			max = anchors[i];
			index = i;
		}
	}
	return (index);
}

int anchorId_decoding_debug(int count, short* capture_data, int preamble_start_index, int type)
{
	//#define DEBUG_DATA
	int shift_index = preamble_start_index + preamble_length + guard_interval_length;
	int copy_length = symbol_length;
	if(shift_index + symbol_length >= process_buffer_length) // [deprecated: avoid array overflow]  never gonna happen
	{
		copy_length = process_buffer_length - shift_index;
	}
	// first extract the samples corresponding to symbol region
	memset(padded_captured_data_for_symbol, 0, N * sizeof(float));
	for(int i = 0; i < copy_length; i++)
	{
		padded_captured_data_for_symbol[2 * i] = capture_data[i + shift_index] / 32768.0;
	}
	/*
	#ifdef DEBUG_DATA
		char file_name[50] = {'\0'};
		sprintf(file_name, "debug/normalized_data_for_symbol_before_fft[%d]_%d.txt", type, count);
		write_float_txt(file_name, padded_captured_data_for_symbol, N);
	#endif
	*/
   fftt(12,1,padded_captured_data_for_symbol,padded_captured_data_for_symbol);
//	cdft(N, -1, padded_captured_data_for_symbol);
	
	#ifdef DEBUG_DECODING
		char file_name[50] = {'\0'};
		memset(file_name, 0, 50 * sizeof(char));
		sprintf(file_name, "debug/normalized_data_for_symbol_after_fft[%d]_%d.txt", type, count);
		write_float_txt(file_name, padded_captured_data_for_symbol, N);
	#endif
	
	float anchors[SYMBOL_NUMBER] = {0};
	int index = 0;
	for(int i = 0; i < SYMBOL_NUMBER; i++)
	{
		xcorr(padded_captured_data_for_symbol, symbol_fft_storage[type][i], result_symbol_complex_data, N);
		magnitude_calculation(result_symbol_complex_data, result_symbol_magnitude, N);
		peak_find(result_symbol_magnitude, N/2, &index, &anchors[i]); // store the maximum correlation results
		anchors[i] = anchors[i] / mean_cal(result_symbol_magnitude, N/2); // ratio between the maximum value and the average
		
		#ifdef DEBUG_DECODING
		/*memset(file_name, 0, 50 * sizeof(char));
		sprintf(file_name, "debug/symbol_fft_storage[%d]_[%d]_%d.txt", type, i, count);
		write_float_txt(file_name, symbol_fft_storage[type][i], N);
		
		memset(file_name, 0, 50* sizeof(char));
		sprintf(file_name, "debug/result_symbol_complex_data[%d]_[%d]_%d.txt", type, i, count);
		write_float_txt(file_name, result_symbol_complex_data, N);	*/

		memset(file_name, 0, 50* sizeof(char));
		sprintf(file_name, "debug/result_symbol_magnitude[%d]_[%d]_%d.txt", type, i, count);
		write_float_txt(file_name, result_symbol_magnitude, N);		
		#endif
	}
	
	float max = anchors[SYMBOL_NUMBER - 1];
	index = SYMBOL_NUMBER - 1;
	for(int i = 0; i < SYMBOL_NUMBER - 1; i++)
	{
		if(anchors[i] > max)
		{
			max = anchors[i];
			index = i;
		}
	}
	return (index);
}

/**
deprecated method 
function: decode the anchor ID
input: capture_data - audio samples in short format
	   start_index - calculated start index 
	   type - UP or DOWN
	   
output: decoded anchor ID
*/
int anchorId_decoding_directly(short* capture_data, int start_index, int type)
{
	// first extract the samples corresponding to symbol region
	memset(padded_captured_data_for_symbol, 0, N * sizeof(float));
	for(int i = 0; i < symbol_length; i++)
	{
		padded_captured_data_for_symbol[2 * i] = capture_data[i + start_index] / 32768.0;
	}
   fftt(12,1,padded_captured_data_for_symbol,padded_captured_data_for_symbol); 
//	cdft(N, -1, padded_captured_data_for_symbol);
	
	float anchors[SYMBOL_NUMBER] = {0};
	int index = 0;
	for(int i = 0; i < SYMBOL_NUMBER; i++)
	{
		xcorr(padded_captured_data_for_symbol, symbol_fft_storage[type][i], result_symbol_complex_data, N);
		magnitude_calculation(result_symbol_complex_data, result_symbol_magnitude, N);
		peak_find(result_symbol_magnitude, N/2, &index, &anchors[i]); // store the maximum correlation results
		anchors[i] = anchors[i] / mean_cal(result_symbol_magnitude, N/2); // ratio between the maximum value and the average
		
	}
	
	float max = anchors[SYMBOL_NUMBER - 1];
	index = SYMBOL_NUMBER - 1;
	for(int i = 0; i < SYMBOL_NUMBER - 1; i++)
	{
		if(anchors[i] > max)
		{
			max = anchors[i];
			index = i;
		}
	}
	return (index);
}

/**
deprecated method
function: decode the anchor ID
input: capture_data - audio samples in short format
	   preamble_start_index - detected preamble start index via correlation
	   type - UP or DOWN
	   
output: decoded anchor ID
*/
int anchorId_decoding(short* capture_data, int preamble_start_index, int type)
{
	int shift_index = preamble_start_index + preamble_length + guard_interval_length;
	int copy_length = symbol_length;
	if(shift_index + symbol_length >= process_buffer_length) // [deprecated: avoid array overflow]  never gonna happen
	{
		copy_length = process_buffer_length - shift_index;
	}
	// first extract the samples corresponding to symbol region
	memset(padded_captured_data_for_symbol, 0, N * sizeof(float));
	for(int i = 0; i < copy_length; i++)
	{
		padded_captured_data_for_symbol[2 * i] = capture_data[i + shift_index] / 32768.0;
	}
  fftt(12,1, padded_captured_data_for_symbol,padded_captured_data_for_symbol);
//	cdft(N, -1, padded_captured_data_for_symbol);
	
	float anchors[SYMBOL_NUMBER] = {0};
	int index = 0;
	for(int i = 0; i < SYMBOL_NUMBER; i++)
	{
		xcorr(padded_captured_data_for_symbol, symbol_fft_storage[type][i], result_symbol_complex_data, N);
		magnitude_calculation(result_symbol_complex_data, result_symbol_magnitude, N);
		peak_find(result_symbol_magnitude, N/2, &index, &anchors[i]); // store the maximum correlation results
		anchors[i] = anchors[i] / mean_cal(result_symbol_magnitude, N/2); // ratio between the maximum value and the average
		
	}
	
	float max = anchors[SYMBOL_NUMBER - 1];
	index = SYMBOL_NUMBER - 1;
	for(int i = 0; i < SYMBOL_NUMBER - 1; i++)
	{
		if(anchors[i] > max)
		{
			max = anchors[i];
			index = i;
		}
	}
	return (index);
}

/**
function: find the maximum value and its corresponding index 
input: result - float array 
	   n - length of the result
output: index - index of the maximum one
	    max - maximum value 
*/
void peak_find(float* result, int n, int* index, float* max)
{
	*max = 0;
	*index = 0;
	for(int i = 0; i < n; i++)
	{
		if(result[i] > *max)
		{
			*max = result[i];
			*index = i;
		}
	}
	
	// ------------------------------------------------------
	// the following code calculate the ratio between the max peak value and the mean of 200 samples ahead of its peak
 	/*
	int W = 200;
	int start = *index - W;
	if(start < 0 )
	{
		start = 0;
	}
	float* p = &result[start];
	
	// rescale the ratio if the number of samples ahead of the index is less than W
	float mean = mean_cal(p, W - start);
	mean = mean * W / (W - start);
	if(abs(mean) < 0.0000001)
	{
		*max = 0;
	}
		
	printf("mean value = %f \n", mean);
	*max = *max / mean; */
	// ------------------------------------------------------
	
	// for correlation using fft, if the reference signal appears in positive time, the range will in [0, n/2]
	// 							  if the reference signal appears in negative time, the range will in [n/2, n] in a reversed order
	if (*index > n/2)
	{
		*index = *index - n;
	}
}
/**
function: get the average value of an array with range
input: result - float array
	   start - start index of the array
	   end - end index of the array
output: average of the array with the specified range
*/
float average_cal(float* result, int start, int end)
{
	if(start < 0)
		start = 0;
	float sum = 0;
	for(int i = start; i < end; i++)
	{
		sum += result[i];
	}
	return (sum / (end - start));
}

/**
function: get the average value of an array
input: result - float array 
	   n - length of the result
output: mean 
*/
float mean_cal(float* result, int n)
{
	float average = 0;
	for(int i = 0; i < n ; i++)
	{
		average += result[i];
	}
	average = average / n;
	return average;
}

/**
function: calculate the magnitude of a complex array
input: complex - array that store the complex data, with even indexes store the real part and odd indexes store the imaginary part
	   length - the length of the complex array
output:	real_magnitude - store the result of the magnitude of the complex array, half size of the complex array
*/
void magnitude_calculation(float* complex, float* real_magnitude, int length)
{
	memset(real_magnitude, 0, sizeof(float) * length/2);
  float temp;
	float tmp[length];
  ne10_mul_float_c(tmp,complex,complex,length);
	for(int i = 0; i < length/2; i++)               //�������Ӧ�ÿ��Բ������㡣
	{
		
		temp = tmp[2*i]+tmp[2*i+1];
		real_magnitude[i] = sqrt(temp);
	}
}
/**
function: calculating the FFT results
input: log2_N - the grade of FFT
	       TYPE - 0:FFT ; 1:IFFT
       in_buf - input_data
	    out_buf - output_data
output: result - complex result of xcorr operation, with even store real part and odd store imaginary part 
*/
int fftt(int log2_N,int TYPE, float* in_buf ,float* out_buf){     //����ż����Ϊʵ����������Ϊ�鲿


     
    
   int N_fft;
   N_fft = pow(2,log2_N); 
//   N_fft = 1<<log2_N; // FFT length
   if(log2_N==12){
    if(TYPE==0){ 
       base = fft_12->in; // input buffer
       memcpy(base,in_buf, N_fft*2*sizeof(float));
	     gpu_fft_execute(fft_12);
	     base = fft_12->out;//	output buffer   
       memcpy(out_buf,base,N_fft*2*sizeof(float)); 
     }
       else{
       base = ifft_12->in;
       memcpy(base,in_buf, N_fft*2*sizeof(float));
	     gpu_fft_execute(ifft_12);  
       base = ifft_12->out;           
       memcpy(out_buf,base,N_fft*2*sizeof(float));
     }
   }
   else{
   if(TYPE==0){   
	     base = fft->in; // input buffer
       memcpy(base,in_buf, N_fft*2*sizeof(float));
	     gpu_fft_execute(fft);
	     base = fft->out;//	output buffer   
       memcpy(out_buf,base,N_fft*2*sizeof(float));  
   }     
   else{
       base = ifft->in;
       memcpy(base,in_buf, N_fft*2*sizeof(float));
	     gpu_fft_execute(ifft);  
       base = ifft->out;           
       memcpy(out_buf,base,N_fft*2*sizeof(float));
   }
   }
	return 0;
}   
/**
function: calculating the correlation results
input: capture_data - normalized data with zero padded after FFT transformation
	   reference_data - normalized data with zero padded after FFT transformation
	   length - size of the capture_data and reference_data, double of FFT size
	   
output: result - complex result of xcorr operation, with even store real part and odd store imaginary part 
*/
void xcorr(float* capture_data, float* reference_data, float* result,const int length)
{
//  ne10_fft_cpx_float32_t src[length/2]; // A source array of input data
//  ne10_fft_cpx_float32_t dst[length/2]; // A destination array for the transformed data
//  ne10_fft_cfg_float32_t cfg;
  
	for(int i = 0; i < length/2; i++)
	{
		a[i]= capture_data[2*i];
		b[i] = capture_data[2*i + 1];
		c[i] = reference_data[2*i];
		d[i] = reference_data[2*i + 1];
	}
  ne10_mul_float_c(e,a,c,(length/2)-1);
  ne10_mul_float_c(f,b,d,(length/2)-1);
  ne10_mul_float_c(g,b,c,(length/2)-1);
  ne10_mul_float_c(h,a,d,(length/2)-1);
  ne10_add_float_c(e,e,f,(length/2)-1);
  ne10_sub_float_c(g,g,h,(length/2)-1);
  result[0]= a[0]*c[0];
  result[1]= b[0]*d[0];
  	for(int i = 1; i < length/2; i++)  //��һ����ʹ��GPU_FFTʱ����ʡȥ��
	{
     result[2*i]=  e[i];
     result[2*i + 1]=  g[i];
	}
//   memcpy(src,result, length);
  // Perform the FFT (for an IFFT, the last parameter should be `1`)
if(length==16384)
   fftt(13,0,result,result);
//   cfg = ne10_fft_alloc_c2c_float32(length/2);
else
//    cfg = ne10_fft_alloc_c2c_float32(length/4);
//  ne10_fft_c2c_1d_float32(dst, src, cfg, 0);
//   memcpy(result,dst, length); 
//   ne10_fft_destroy_c2c_float32(cfg);
fftt(12,0,result,result);
//	cdft(length, 1, result);
	int divider = length / 2;
ne10_divc_float_c(result,result,divider,length);
//	for(int i = 0; i < length; i++)
//	{
//		result[i]= result[i]/divider; 
//	}
}