#ifndef JSON_WRAPER_H
#define JSON_WRAPER_H

#include "basic_headers.h"
#include <json-c/json.h>
#include <json-c/json_object.h>
#include <json-c/json_tokener.h>
#include <json-c/json_util.h>

//----------json keys---------------------
#define FIRST_ANCHORID	"firstAnchorId"
#define SECOND_ANCHORID	"secondAnchorId"
#define ANCHOR_ID  "identity"
#define TDOA	"tdoa"
#define PARITY  "parity"

#define TMP_BUFFER_LEN    50

typedef struct Parameters
{
	char server_ip[15];
	int schedule_port;
	int upload_port;
	int anchorId;
	int detection_threshold;
}Parameters;

typedef struct CaptureBeaconMessage
{
	int self_anchorId;
	int captured_anchorId;
	int captured_sequence;
	int preamble_index;
	long int looper_counter;
}CaptureBeaconMessage;

bool is_my_timeslot(int anchorId, const char* msg, int *sequence);
//extern bool is_my_timeslot(int anchorId, const char* msg);
extern void encode_timestamp(int first_anchorId, int second_anchorId, int tdoa, char *msg);
extern bool decode_timestamp(int anchorId, char *type, const char* msg);
extern void load_prameter_profiles(const char* file_path, Parameters* parameters);
extern void encode_captured_beacon_message(CaptureBeaconMessage capture_beacon_message, char* msg);
//extern void load_prameter_profiles();

#endif

