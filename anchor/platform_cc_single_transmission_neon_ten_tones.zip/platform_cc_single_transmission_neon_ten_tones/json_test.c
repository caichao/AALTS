#include <stdint.h>
#include <stdio.h>
#include <string.h>

#include <stdlib.h> /* exit() */
#include <errno.h>
#include <unistd.h> /* pause() */
#include <ctype.h>
#include <sys/ioctl.h>
#include <signal.h> /* sigaction() */
#include <time.h>
#include <semaphore.h>

#include <pthread.h>

#include <math.h>

#include <alsa/asoundlib.h>
#include<sys/types.h>  
#include<netinet/in.h>  
#include<netdb.h>  
#include<sys/wait.h>  

#include <sys/socket.h> /* for socket(), connect(), send(), and recv() */
#include <arpa/inet.h>  /* for sockaddr_in and inet_addr() */
#include <stdbool.h>

// GPIO
#include <bcm2835.h>
#include "json.h"
#include "json_object.h"
#include "json_tokener.h"
#include "json_util.h"

int main(int argc, char *argv[])
{
	// the steps to encode the tdoa information
	json_object *time_stamp;
	time_stamp = json_object_new_object();
	json_object_object_add(time_stamp, "anchorId", json_object_new_string("124"));
	json_object_object_add(time_stamp, "TDOA", json_object_new_string("234"));
	printf("%s\n", json_object_to_json_string(time_stamp));

	char tmp[100] = {0};
	sprintf(tmp, "%s", json_object_to_json_string(time_stamp));
	printf("string length = %d\n", strlen(tmp));
	json_object_put(time_stamp);//free	
	
	// the step to decode the tdoa information
	json_object *result_json = json_tokener_parse(tmp);
    json_object *tmp_obj = json_object_object_get(result_json, "anchorId");
    int anchorId = json_object_get_int(tmp_obj);
    tmp_obj = json_object_object_get(result_json, "TDOA");
    int tdoa = json_object_get_int(tmp_obj);
	printf("anchorId=%d, tdoa=%d\n", anchorId, tdoa);
	
	//json_object_put(result_json);//free	
	json_object_put(tmp_obj);//free	
	
	//json_object_to_file(filepath, json_object); //write json_object to file

	memset(tmp, 0, sizeof(char) * 100);
    json_object *file_test = json_object_from_file("global_prams.txt");  //read json_object from file
    json_object *tmp_file = json_object_object_get(file_test, "server_ip");
	const char* server_ip = json_object_get_string(tmp_file);
	//int anchorId = json_object_get_int(tmp_obj);
    //int tdoa = json_object_get_int(tmp_obj);
	printf("server_ip = %s", server_ip);
	json_object_put(file_test);//free	
}
