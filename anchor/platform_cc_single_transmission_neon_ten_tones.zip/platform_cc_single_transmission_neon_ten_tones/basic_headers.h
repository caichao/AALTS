#ifndef BASIC_HEADERS
#define BASIC_HEADERS

//========================================
// basic header files
//========================================
#include <stdint.h>
#include <stdio.h>
#include <string.h>

// about mkdir and judge the dir existence
#include<sys/stat.h>  
#include<sys/types.h>  
#include <unistd.h>

#include <stdlib.h> /* exit() */
#include <errno.h>
#include <unistd.h> /* pause() */
#include <ctype.h>
#include <sys/ioctl.h>
#include <signal.h> /* sigaction() */
#include <time.h>
#include <semaphore.h>

#include <pthread.h>

#include <math.h>

#include <alsa/asoundlib.h>
#include<sys/types.h>  
#include<netinet/in.h>  
#include<netdb.h>  
#include<sys/wait.h>  

#include <sys/socket.h> /* for socket(), connect(), send(), and recv() */
#include <arpa/inet.h>  /* for sockaddr_in and inet_addr() */
#include <stdbool.h>

// GPIO
#include <bcm2835.h>

#endif