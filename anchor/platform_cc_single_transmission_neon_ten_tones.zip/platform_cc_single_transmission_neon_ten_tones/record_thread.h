#ifndef RECORD_THREAD_H
#define RECORD_THREAD_H

#include "basic_headers.h"

#include "global_variables.h"

//extern short audio_buffer[REC_BUFFER_LEN]; 
//extern bool is_recording_ready;

extern void *RecordThread(void *recordThreadArgs);
extern void is_recording_ready();
extern void increase_counter();
extern void decrease_counter();

// In record_thread.c
struct RecordThreadArgs
{
  snd_pcm_t* device;
  short* p_audio_buffer;
};


#endif



