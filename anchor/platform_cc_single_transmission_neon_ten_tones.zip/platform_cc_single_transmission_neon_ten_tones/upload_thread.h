#ifndef UPLOAD_THREAD_H
#define UPLOAD_THREAD_H

#include "basic_headers.h"
#include "json_wraper.h"
#include "global_variables.h"

/*
#define DEBUG

#ifdef DEBUG
#define SERVER_IP  "192.168.1.101"
#define SERVER_PORT 33333
#endif 
*/

#define SEND_MESSAGE_LEN  512

char upload_message[SEND_MESSAGE_LEN];

extern void *UploadThread();
extern void upload_timestamp(int first_anchorId, int second_anchorId, int tdoa);
extern void upload_capture_beacon_message(CaptureBeaconMessage capture_beacon_message);
#endif

