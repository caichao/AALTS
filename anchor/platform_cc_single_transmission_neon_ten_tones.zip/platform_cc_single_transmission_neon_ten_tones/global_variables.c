#include "global_variables.h"

//pthread_mutex_t mutexLockAudioFifo;

short audio_buffer[REC_BUFFER_LEN];
//short audio_buffer;

Parameters g_parameter;

void global_variable_initializer()
{
	#define DEBUG_DATA
	
	#ifdef DEBUG_DATA 
		// create a folder that store all the debug files
		if(access("debug",F_OK) != 0)
		{
			mkdir("debug", 0777);
		}
	#endif
	
	#ifdef DEBUG_THRESHOLD 
		// create a folder that store all the debug files
		if(access("debug",F_OK) != 0)
		{
			mkdir("debug", 0777);
		}
	#endif	
	
  
	const char* file_path = "global_prams.txt";
    load_prameter_profiles(file_path, &g_parameter);
	printf("server_ip = %s, schedule_port = %d, upload_port = %d, anchorId = %d\n", g_parameter.server_ip, g_parameter.schedule_port, g_parameter.upload_port, g_parameter.anchorId);
	printf("preamble detection threshold = %d\n", g_parameter.detection_threshold);
    memset(audio_buffer, 0, sizeof(short)*REC_BUFFER_LEN);
}