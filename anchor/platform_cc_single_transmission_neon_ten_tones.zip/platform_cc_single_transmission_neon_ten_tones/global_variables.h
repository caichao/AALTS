#ifndef GLOBAL_VARIABLES_H
#define GLOBAL_VARIABLES_H

#include "basic_headers.h"


//#include "record_thread.h"

#include "play_thread.h"

#include "json_wraper.h"

//========================================
// macro
//========================================

#define SAMPLE_RATE 48000

// if enable play_thread
#define ENABLE_TRANSMISSION

//#define DEBUG

//#define CHECK_PREAMBLE_SYMBOL

//#define CHECK_BEACON_MESSAGE

//#define DEBUG_PLAY

//#define DEBUG_WAVE

//#define DEBUG_DATA

//#define DEBUG_DECODING

//#define DEBUG_DATA_MIC

#define REC_BUFFER_LEN 4096

//#define DEBUG_TIME_SPEND

//#define DEBUG_THRESHOLD

//#define ENABLE_SQUARE

/* #ifdef DEBUG_DATA_MIC
#define REC_BUFFER_LEN 10240
#else
#define REC_BUFFER_LEN 4096
#endif
 */
// GPIO - HIGH: with mic amplifier ; LOW: without mic amplifier
#define PIN_AMPLIFIER_SWITCH RPI_GPIO_P1_08 //P1_08: GPIO14


//========================================
// variable declaration
//========================================



//extern pthread_mutex_t mutexLockAudioFifo;
extern short audio_buffer[REC_BUFFER_LEN];

extern Parameters g_parameter;

//========================================
// function declaration
//========================================
extern void global_variable_initializer();
//extern void *RecordThread(void *recordThreadArgs)
//========================================
// customized structure declaration
//========================================



#endif





