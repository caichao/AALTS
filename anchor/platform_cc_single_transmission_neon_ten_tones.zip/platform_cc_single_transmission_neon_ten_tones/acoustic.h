#ifndef ACOUSTIC_H
#define ACOUSTIC_H

#include "basic_headers.h"
#include "write_wav.h"

#define UP  0
#define DOWN  1

#define PREAMBLE_DURATION  0.04
#define SYMBOL_DURATION  0.03
#define PREAMBLE_BANDWIDTH  4000
#define SYMBOL_BANDWIDTH  1000
#define FMIN 18000
#define FMAX 22000
#define PREAMBLE_TYPE  2
#define SYMBOL_NUMBER  4
#define GUARD_INTERVAL 0.005
#define BEACON_DURATION	0.11

#define TONE_LOW_FMIN  17000
#define TONE_HIGH_FMIN 17500
#define TONE_INTERVAL  100
#define NUMBER_OF_TONE 10


#define PI 3.141592654
#define SHORT_MAX  32767

#define SAMPLING_RATE  48000

//extern double *buffer;
extern short **preambles;
extern short ***symbols;
extern short *beacon_message;

extern int preamble_length;
extern int symbol_length; 
extern int guard_interval_length;
extern int beacon_message_length;

extern void encoding_beacon_message(int id, int sequence);
extern void init();



void generate_preamble(short* sample, int type);
void waveform_reshape(float* samples, int start_index, int end_index);
void generate_symbol(short* sample, int f, int type);
void chirp_signal(int fs, int fmin, float t, int b, float* s, int type);
void multitone_signal(int fs, int fmin, int frequency_interval, int number_of_tone, float duration, float* s);
float max(float* s, int n);
void signal_normalization(float* s, int n);
void preamble_generation(short *sample, int type);
void symbol_generation(short* sample, int f, int type);

#endif

