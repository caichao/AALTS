#ifndef FIFO_H
#define FIFO_H

#include "basic_headers.h"


extern void pop(short* data);
extern void push(short* data);
extern void fifo_init();

#endif

