//#include "play_thread.h"
#include <semaphore.h>
#include "global_variables.h"
#include "acoustic.h"


//pthread_t pid;
sem_t sem;

//======================================================================
// transmit_beacon_message
// allow the anchor to transmit message
//
//======================================================================
void transmit_beacon_message()
{
	//is_time_to_play = true;
	sem_post(&sem);
}

//======================================================================
// PlayThread
// Routine:   
//		1. encoding_beacon_message(1, UP);  -- this fill the beacon_message array with intended values
//		2. transmit_beacon_message(); -- this step open the sem lock and allow the thread to play the audio clips
//
//======================================================================
void *PlayThread(void *playThreadArgs)
{
  //setSchedulerHighestPriority();
  //memset(play_buffer, 0, sizeof(short) * PLAY_BUFFER_LEN);
  #ifdef DEBUG_PLAY
  int anchorId = g_parameter.anchorId ;
  #endif 
  struct PlayThreadArgs *args = (struct PlayThreadArgs *)playThreadArgs;
  #ifndef DEBUG_PLAY
  sem_init(&sem, 1, 0);
  #endif
  int err;
  if ((err = snd_pcm_prepare (args->device)) < 0) {
    fprintf (stderr, "cannot prepare audio interface for use (%s)\n", snd_strerror (err));
    return (NULL);
  }
  //short empty[100] = {0};
  printf("[play thread] is ready! \n");
  // TBD: fill this warm up speaker buffer with pure tone signal
  int warm_up_speaker_length = 50;
  //int cool_down_speaker_length = 100;
  short* buf = (short *)malloc((beacon_message_length + warm_up_speaker_length * 2) * sizeof(short));
  int buf_length = beacon_message_length + warm_up_speaker_length * 2;
  memset(buf, 0, (beacon_message_length + warm_up_speaker_length * 2) * sizeof(short));
  
/*   for(int i = 0; i < warm_up_speaker_length; i++)
  {
	  buf[i] = 32768.0 * i / warm_up_speaker_length * cos(2 * PI * 18000 * i / SAMPLE_RATE);
  } */
  
  // remove audible noise
  for(int i = 0; i < warm_up_speaker_length; i++)
  {
	  buf[i + warm_up_speaker_length + beacon_message_length] = 32768.0 * (warm_up_speaker_length - i) / warm_up_speaker_length * cos(2 * PI * 20000 * i / SAMPLE_RATE);
	  buf[i] = 32768.0 * (i) / warm_up_speaker_length * cos(2 * PI * 20000 * i / SAMPLE_RATE);
  }
  
  #ifdef DEBUG_PLAY
	int looper = 0;
	encoding_beacon_message(anchorId, looper % 4);
	memcpy(buf + warm_up_speaker_length, beacon_message, beacon_message_length * sizeof(short));
  #endif
  
  //#define CHECK_BEACON_MESSAGE
  
  #ifdef CHECK_BEACON_MESSAGE
	char tmp[100] = {0};
  #endif
  while(1)
  // transmit beacon
  {
	  //printf("play thread looper\n");

	  #ifndef DEBUG_PLAY
	  sem_wait(&sem); // wait for any transmission command
	  
	  memcpy(buf + warm_up_speaker_length, beacon_message, beacon_message_length * sizeof(short));
	  #endif 
	  
	  // should first prepare, then transmit the beacon message
	  int err;
	  if ((err = snd_pcm_prepare (args->device)) < 0) {
		fprintf (stderr, "cannot prepare audio interface for use (%s)\n", snd_strerror (err));
		return (NULL);
	  }
	  
		
	  if ((err = snd_pcm_writei(args->device, buf, buf_length)) != buf_length) {
	  fprintf (stderr, "write to audio interface failed (%s)\n", snd_strerror (err));
	  return (NULL);
      }
	  
	  #ifdef DEBUG_PLAY
		looper++;
		encoding_beacon_message(anchorId, looper % 4);
		memcpy(buf + warm_up_speaker_length, beacon_message, beacon_message_length * sizeof(short));
	  #endif

	  #ifdef CHECK_BEACON_MESSAGE
		static int counter = 0;
		memset(tmp, 0, sizeof(char) * 100);
		sprintf(tmp, "debug/check_beacon_message[%d].txt", counter);
		write_short_txt(tmp, beacon_message, beacon_message_length);
		counter++;
	    //write_short_txt("debug/check_beacon_message.txt", beacon_message, beacon_message_length);
	  #endif 
	  
	  #ifdef DEBUG_PLAY
	  #ifdef DEBUG_WAVE
		  bcm2835_delay(1000);
	  #else
		  bcm2835_delay(2000);
	  #endif 
		
		printf("Beacon message transmitted with anchorId = %d, sequence = %d\n", anchorId, looper % 4);
	  #endif
	//}
  }
  sem_destroy(&sem);

  return (NULL); 
}