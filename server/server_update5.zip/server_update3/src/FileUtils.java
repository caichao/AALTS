import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * Created by cc on 2017/3/24.
 */

public class FileUtils {
    //public static final String SDPATH = Environment.getExternalStorageDirectory()+ File.separator;//"/sdcard/";
    public static final String SDPATH = "./";

    public static void saveParticles(float[][] p, int[] index, String name) {
        File file = new File(SDPATH + name + ".txt");
        FileWriter fw = null;
        try {
            fw = new FileWriter(file);
            if (!file.exists())
                file.createNewFile();
            for (int i = 0; i < index.length; i++) {
                fw.write(String.valueOf(p[index[i]][0]) + "\t");
                fw.write(String.valueOf(p[index[i]][1]) + "\r\n");

                fw.flush();
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (fw != null)
                    fw.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public static void saveParticles(float[][] p, int len, String name){
        File file = new File(SDPATH+name+".txt");
        FileWriter fw = null;
        try {
            fw = new FileWriter(file);
            if(!file.exists())
                file.createNewFile();
            for(int i = 0; i < len ; i++){
                fw.write(String.valueOf(p[i][0]) + "\t");
                fw.write(String.valueOf(p[i][1]) + "\r\n");

                fw.flush();
            }
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            try {
                if(fw != null)
                    fw.close();
            }catch (Exception e){
                e.printStackTrace();
            }
        }
    }

    public static void saveBytes(short[] bytes, String name){
        File file = new File(SDPATH+name+".txt");
        FileWriter fw = null;
        try {
            fw = new FileWriter(file);
            if(!file.exists())
                file.createNewFile();
            for(int i = 0; i < bytes.length ; i++){
                fw.write(String.valueOf(bytes[i]) + "\r\n");
                fw.flush();
            }
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            try {
                if(fw != null)
                    fw.close();
            }catch (Exception e){
                e.printStackTrace();
            }
        }
    }

    public static void saveBytes(double[] bytes, String name){
        File file = new File(SDPATH+name+".txt");
        FileWriter fw = null;
        try {
            fw = new FileWriter(file);
            if(!file.exists())
                file.createNewFile();
            for(int i = 0; i < bytes.length ; i++){
                fw.write(String.valueOf(bytes[i]) + "\r\n");
                fw.flush();
            }
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            try {
                if(fw != null)
                    fw.close();
            }catch (Exception e){
                e.printStackTrace();
            }
        }
    }

    public static void saveDoubleList(List<Double> bytes, String name){
        File file = new File(SDPATH+name+".txt");
        FileWriter fw = null;
        fileOperation(file, fw, bytes);
    }

    public static void saveFloatList(List<Float> bytes, String name){
        File file = new File(SDPATH+name+".txt");
        FileWriter fw = null;

    }

    private static void fileOperation(File file, FileWriter fw, List bytes){
        try {
            fw = new FileWriter(file);
            if(!file.exists())
                file.createNewFile();
            for(int i = 0; i < bytes.size() ; i++){
                fw.write(String.valueOf(bytes.get(i)) + "\r\n");
                fw.flush();
            }
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            try {
                if(fw != null)
                    fw.close();
            }catch (Exception e){
                e.printStackTrace();
            }
        }
    }

    public static double[] readTxt(String name, int length){
        String tmp = "";
        FileReader fileReader = null;
        BufferedReader bufferedReader = null;
        double[] pcm = null;
        try{
            fileReader = new FileReader(new File(SDPATH + name));
            bufferedReader = new BufferedReader(fileReader);
            pcm = new double[length];
            int i = 0;
            while ((tmp = bufferedReader.readLine()) != null){
                pcm[i++] = (short) Float.parseFloat(tmp);
            }
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            try{
                if(bufferedReader!= null)
                    bufferedReader.close();
                if(fileReader != null)
                    fileReader.close();
            }catch (Exception e){
                e.printStackTrace();
            }
        }
        return pcm;
    }

    public static double[] readFilterCoefficient(String name, int length){
        String tmp = "";
        FileReader fileReader = null;
        BufferedReader bufferedReader = null;
        double[] filterCoefficient = null;
        try{
            fileReader = new FileReader(new File(SDPATH + name));
            bufferedReader = new BufferedReader(fileReader);
            filterCoefficient = new double[length];
            int i = 0;
            while ((tmp = bufferedReader.readLine()) != null){
                filterCoefficient[i++] = Double.parseDouble(tmp);
            }
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            try{
                if(bufferedReader!= null)
                    bufferedReader.close();
                if(fileReader != null)
                    fileReader.close();
            }catch (Exception e){
                e.printStackTrace();
            }
        }
        return filterCoefficient;
    }

    public static void saveLocalizationResults(float x, float y, float z, String fileName){
        PrintWriter out = null;
        String result = String.format("%.4f\t%.4f\t%.4f", x, y, z);
        try {
            out = new PrintWriter(new BufferedWriter(new FileWriter(fileName, true)));
            out.println(result);
        }catch (IOException e) {
            System.err.println(e);
        }finally{
            if(out != null){
                out.close();
            }
        }
    }

    public static void saveBeaconMessage(String fileName, CapturedBeaconMessage capturedBeaconMessage){
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(capturedBeaconMessage.selfAnchorId).append("\t")
                .append(capturedBeaconMessage.capturedAnchorId).append("\t")  //anchor x .txt
                .append(capturedBeaconMessage.capturedSequence).append("\t")
                .append(capturedBeaconMessage.looperCounter).append("\t")
                .append(capturedBeaconMessage.preambleIndex).append("\t")
                .append(capturedBeaconMessage.speed).append("\n");
        saveStringMessage(fileName, stringBuilder.toString());
    }

    public static void saveBeaconMessage(String fileName, List<CapturedBeaconMessage> list){
        StringBuilder stringBuilder = new StringBuilder();
        for(CapturedBeaconMessage capturedBeaconMessage : list){
            try {
                stringBuilder.append(JSONUtils.toJson(capturedBeaconMessage)).append("\r\n");
            }catch (Exception e){
                e.printStackTrace();
            }
        }
        saveStringMessage(fileName, stringBuilder.toString());
    }
    public static void saveStringMessage(String fileName, String message){
        PrintWriter out = null;
        try {
            out = new PrintWriter(new BufferedWriter(new FileWriter(fileName, true)));
            out.println(message);
        }catch (Exception e) {
            System.err.println(e);
        }finally{
            if(out != null){
                out.close();
            }
        }
    }


    /*
    * 该方法用于查找results目录下最新生成的那个位置文件
    * */
    public static String getLatestFile(String path){
        // get file list where the path has
        File file = new File(path);
        // get the folder list
        File[] array = file.listFiles();
        String latestFile = null;
        for(int i=0;i<array.length - 1;i++){
            if(array[i].isFile()){
                int temp = array[i + 1].getName().compareTo(array[i].getName());
                if(temp>0){
                    latestFile=array[i+1].getName();
                }
            }else if(array[i].isDirectory()){
                getLatestFile(array[i].getPath());
            }
        }
        return latestFile;
    }

    /*
     * 该方法用于查找results目录下最新生成的那个位置文件
     * */
    public static File getLatestLocationFile(String path){
        // get file list where the path has
        File locationDir = new File(path);
        // get the folder list
        File[] locationFiles = locationDir.listFiles();
        File latestFile = null;
        for(int i=0;i<locationFiles.length - 1;i++){
            if(locationFiles[i].isFile()){
                int temp = locationFiles[i + 1].getName().compareTo(locationFiles[i].getName());
                if(temp>0){
                    latestFile=locationFiles[i+1];
                }
            }
        }
        return latestFile;
    }


    /*
     *   剪切文件或者文件夹(复制+删除)
     * */
    public static boolean cutGeneralFile(String srcPath, String destDir) {
        if (!copyGeneralFile(srcPath, destDir)) {
            System.out.println("复制失败导致剪切失败!");
            return false;
        }
        if (!deleteGeneralFile(srcPath)) {
            System.out.println("删除源文件(文件夹)失败导致剪切失败!");
            return false;
        }
        System.out.println("剪切成功!");
        return true;
    }

    /*
     *   复制文件或文件夹
     * */
    public static boolean copyGeneralFile(String srcPath, String destDir) {
        boolean flag = false;
        File file = new File(srcPath);
        if (!file.exists()) {
            System.out.println("源文件或源文件夹不存在!");
            return false;
        }
        if (file.isFile()) { // 源文件
            System.out.println("下面进行文件复制!");
            flag = copyFile(srcPath, destDir);   //将文件复制到指定目录
        } else if (file.isDirectory()) {
            System.out.println("下面进行文件夹复制!");
            flag = copyDirectory(srcPath, destDir);  //利用递归，将一文件夹 (包括该文件夹里的所有子文件夹和文件) 复制到另外一个文件夹目录下
        }

        return flag;
    }

    /* 辅助方法
     *   复制文件,from srcPath to destDir
     * */
    private static boolean copyFile(String srcPath, String destDir) {
        boolean flag = false;

        File srcFile = new File(srcPath);
        if (!srcFile.exists()) { // 源文件不存在
            System.out.println("源文件不存在");
            return false;
        }
        // 获取待复制文件的文件名
        String fileName = srcPath.substring(srcPath.lastIndexOf(File.separator));
        String destPath = destDir + fileName;
        if (destPath.equals(srcPath)) { // 源文件路径和目标文件路径重复
            System.out.println("源文件路径和目标文件路径重复!");
            return false;
        }
        File destFile = new File(destPath);
        if (destFile.exists() && destFile.isFile()) { // 该路径下已经有一个同名文件
            System.out.println("目标目录下已有同名文件!");
            return false;
        }

        File destFileDir = new File(destDir);
        destFileDir.mkdirs();
        try {
            FileInputStream fis = new FileInputStream(srcPath);
            FileOutputStream fos = new FileOutputStream(destFile);
            byte[] buf = new byte[1024];
            int c;
            while ((c = fis.read(buf)) != -1) {
                fos.write(buf, 0, c);
            }
            fis.close();
            fos.close();

            flag = true;
        } catch (IOException e) {
            //
        }

        if (flag) {
            System.out.println("复制文件成功!");
        }

        return flag;
    }

    /* 辅助方法
     *   复制文件夹
     * */
    private static boolean copyDirectory(String srcPath, String destDir) {
        System.out.println("复制文件夹开始!");
        boolean flag = false;

        File srcFile = new File(srcPath);
        if (!srcFile.exists()) { // 源文件夹不存在
            System.out.println("源文件夹不存在");
            return false;
        }
        // 获得待复制的文件夹的名字，比如待复制的文件夹为"E://dir"则获取的名字为"dir"
        String dirName = getDirName(srcPath);
        // 目标文件夹的完整路径
        String destPath = destDir + File.separator + dirName;
        // System.out.println("目标文件夹的完整路径为：" + destPath);

        if (destPath.equals(srcPath)) {
            System.out.println("目标文件夹与源文件夹重复");
            return false;
        }
        File destDirFile = new File(destPath);
        if (destDirFile.exists()) { // 目标位置有一个同名文件夹
            System.out.println("目标位置已有同名文件夹!");
            return false;
        }
        destDirFile.mkdirs(); // 生成目录

        File[] fileList = srcFile.listFiles(); // 获取源文件夹下的子文件和子文件夹
        if (fileList.length == 0) { // 如果源文件夹为空目录则直接设置flag为true
            flag = true;
        } else {
            for (File temp : fileList) {
                if (temp.isFile()) { // 文件
                    flag = copyFile(temp.getAbsolutePath(), destPath);
                } else if (temp.isDirectory()) { // 文件夹
                    flag = copyDirectory(temp.getAbsolutePath(), destPath);
                }
                if (!flag) {
                    break;
                }
            }
        }

        if (flag) {
            System.out.println("复制文件夹成功!");
        }

        return flag;
    }

    /* 辅助方法
     *   获取待复制文件夹的文件名
     * */
    private static String getDirName(String dir) {
        if (dir.endsWith(File.separator)) { // 如果文件夹路径以"//"结尾，则先去除末尾的"//"
            dir = dir.substring(0, dir.lastIndexOf(File.separator));
        }
        return dir.substring(dir.lastIndexOf(File.separator) + 1);
    }

    /*
     *   删除文件或者文件夹
     * */
    public static boolean deleteGeneralFile(String path) {
        boolean flag = false;

        File file = new File(path);
        if (!file.exists()) { // 文件不存在
            System.out.println("要删除的文件不存在！");
        }

        if (file.isDirectory()) { // 如果是目录，则单独处理
            flag = deleteDirectory(file.getAbsolutePath());  //删除一个文件夹里的所有东西
        } else if (file.isFile()) {
            flag = deleteFile(file);  //(系统方法) 删除文件
        }

        if (flag) {
            System.out.println("删除文件或文件夹成功!");
        }

        return flag;
    }

    /* 辅助方法
     *       删除文件夹  (利用递归，将一个文件夹里面的东西删除干净)
     * */
    private static boolean deleteDirectory(String path) {
        boolean flag = true;
        File dirFile = new File(path);
        if (!dirFile.isDirectory()) {
            return flag;
        }
        File[] files = dirFile.listFiles();
        for (File file : files) { // 删除该文件夹下的文件和文件夹
            // Delete file.
            if (file.isFile()) {
                flag = deleteFile(file);
            } else if (file.isDirectory()) {// Delete folder
                flag = deleteDirectory(file.getAbsolutePath());
            }
            if (!flag) { // 只要有一个失败就立刻不再继续
                break;
            }
        }
        flag = dirFile.delete(); // 删除空目录
        return flag;
    }

    /*
     *   系统自带的删除文件的函数
     * */
    private static boolean deleteFile(File file) {
        return file.delete();
    }

    /**
     * 压缩成ZIP 方法1
     * @param srcDir 压缩文件夹路径
     * @param out    压缩文件输出流
     * @param KeepDirStructure  是否保留原来的目录结构,true:保留目录结构;
     *                          false:所有文件跑到压缩包根目录下(注意：不保留目录结构可能会出现同名文件,会压缩失败)
     * @throws RuntimeException 压缩失败会抛出运行时异常
     */
    public static void toZip(String srcDir, OutputStream out, boolean KeepDirStructure)
            throws RuntimeException{
        long start = System.currentTimeMillis();
        ZipOutputStream zos = null ;
        try {
            zos = new ZipOutputStream(out);
            File sourceFile = new File(srcDir);
            compress(sourceFile,zos,sourceFile.getName(),KeepDirStructure);
            long end = System.currentTimeMillis();
            System.out.println("压缩完成，耗时：" + (end - start) +" ms");
        } catch (Exception e) {
            throw new RuntimeException("zip error from ZipUtils",e);
        }finally{
            if(zos != null){
                try {
                    zos.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }


    /**
     * 递归压缩方法
     * @param sourceFile 源文件
     * @param zos        zip输出流
     * @param name       压缩后的名称
     * @param KeepDirStructure  是否保留原来的目录结构,true:保留目录结构;
     *                          false:所有文件跑到压缩包根目录下(注意：不保留目录结构可能会出现同名文件,会压缩失败)
     * @throws Exception
     */

    private static final int  BUFFER_SIZE = 2 * 1024;
    private static void compress(File sourceFile, ZipOutputStream zos, String name,
                                 boolean KeepDirStructure) throws Exception{
        byte[] buf = new byte[BUFFER_SIZE];
        if(sourceFile.isFile()){
            // 向zip输出流中添加一个zip实体，构造器中name为zip实体的文件的名字
            zos.putNextEntry(new ZipEntry(name));
            // copy文件到zip输出流中
            int len;
            FileInputStream in = new FileInputStream(sourceFile);
            while ((len = in.read(buf)) != -1){
                zos.write(buf, 0, len);
            }
            // Complete the entry
            zos.closeEntry();
            in.close();
        } else {
            File[] listFiles = sourceFile.listFiles();
            if(listFiles == null || listFiles.length == 0){
                // 需要保留原来的文件结构时,需要对空文件夹进行处理
                if(KeepDirStructure){
                    // 空文件夹的处理
                    zos.putNextEntry(new ZipEntry(name + "/"));
                    // 没有文件，不需要文件的copy
                    zos.closeEntry();
                }
            }else {
                for (File file : listFiles) {
                    // 判断是否需要保留原来的文件结构
                    if (KeepDirStructure) {
                        // 注意：file.getName()前面需要带上父文件夹的名字加一斜杠,
                        // 不然最后压缩包中就不能保留原来的文件结构,即：所有文件都跑到压缩包根目录下了
                        compress(file, zos, name + "/" + file.getName(),KeepDirStructure);
                    } else {
                        compress(file, zos, file.getName(),KeepDirStructure);
                    }
                }
            }
        }
    }
}
