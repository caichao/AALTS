import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.GeneralPath;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/****
 *DrawSmoothCurve
 * 该类用来绘制新窗口的曲线
 * */


class DrawSmoothCurve extends JPanel {
    int[][] array;

    {
        try {
            array = new getLocation().getData();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public  Point[] getPoints(){
        Point[] data = new Point[array[0].length];
        for(int i=0;i<array[0].length;i++){
            data[i] = new Point(array[0][i],array[1][i]);
        }
        return data;
    }



    //        private Point[] points = {
//                new Point(5,5),
//                new Point(9,0),
//                new Point(100, 300),
//                new Point(100, 100),
//                new Point(200, 100),
//                new Point(300, 100),
//                new Point(330, 80),
//                new Point(150, 70),
//                new Point(0,0)
//        };
    private Point[] points = getPoints();



    GeneralPath path = new GeneralPath();

    public DrawSmoothCurve() {
        path.moveTo(points[0].x, points[0].y);

        for (int i = 0; i < points.length-1; ++i) {
            Point sp = points[i];
            Point ep = points[i+1];
            Point c1 = new Point((sp.x + ep.x)/2, sp.y);
            Point c2 = new Point((sp.x + ep.x)/2, ep.y);

            path.curveTo(c1.x, c1.y, c2.x, c2.y, ep.x, ep.y);
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setStroke(new BasicStroke(2));
        g2d.drawRect((int) (DrawMainFrame.originX*MainFrame.xTrans*1.5),(int) ((DrawMainFrame.originY-DrawMainFrame.yInerAxis)*1.5*MainFrame.yTrans),(int)(DrawMainFrame.xInerAxis*MainFrame.xTrans*1.5),(int)(DrawMainFrame.yInerAxis*MainFrame.yTrans*1.5));
        g2d.translate(0, 0);//原点DrawMainFrame
        g2d.setStroke(new BasicStroke(1.5f));
        MainFrame.drawMainFrame.drawAnchor(DrawMainFrame.AnchorScale,g2d,2);
        g2d.draw(path);
        g2d.setColor(Color.BLACK);
        g2d.setStroke(new BasicStroke(2.0f));

        for (int i = 0; i < points.length; ++i) {
            g2d.setColor(Color.GRAY);
            g2d.fillOval(points[i].x-4, points[i].y-4, 8, 8);
            g2d.setColor(Color.BLACK);
            g2d.drawOval(points[i].x-4, points[i].y-4, 8, 8);
        }
    }



    public void createAndShowGui() {
        JFrame frame = new JFrame("Target Trace");
        frame.setContentPane(new DrawSmoothCurve());
        //frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1400*MainFrame.xTrans, 850*MainFrame.yTrans);
        frame.setResizable(false);
        frame.setLocation(10,10);
        frame.setLayout(null);
        //frame.setLocationRelativeTo(null);
        frame.setVisible(true);

        JButton savePic = new JButton("Trace");
        frame.add(savePic);
        savePic.setBounds(800*MainFrame.xTrans,600*MainFrame.yTrans,100*MainFrame.xTrans,30*MainFrame.yTrans);

        savePic.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                savePic(frame);
            }
        });
    }


    public  void  savePic(JFrame jf){
        //得到窗口内容面板
        Container content=jf.getContentPane();
        //创建缓冲图片对象
        BufferedImage img=new BufferedImage(
                jf.getWidth(),jf.getHeight(),BufferedImage.TYPE_INT_RGB);
        //得到图形对象
        Graphics2D g2d = img.createGraphics();
        //将窗口内容面板输出到图形对象中
        content.printAll(g2d);
        //保存为图片
        SimpleDateFormat df = new SimpleDateFormat("MM-dd_HH_mm");//设置日期格式
        File f=new File("trace/Trace"+df.format(new Date())+".jpg");
        try {
            ImageIO.write(img, "jpg", f);
        } catch (IOException e) {
            e.printStackTrace();
        }
        //释放图形对象
        g2d.dispose();
    }






    class Data{
        private double x;
        private double y;
        Data(double x,double y){
            this.x=x;
            this.y=y;
        }
        public double getX() {
            return x;
        }
        public void setX(double x) {
            this.x = x;
        }
        public double getY() {
            return y;
        }
        public void setY(double y) {
            this.y = y;
        }
    }
    class getLocation {
        public  int[][] getData() throws IOException {
            String path = "results";
            String latestPath = FileUtils.getLatestFile(path);//找到最新生成的文本文档
            //System.out.println(latestPath);

            BufferedReader br = new BufferedReader(new FileReader("results/"+latestPath));
            java.util.List<String> list=new ArrayList<>();

            String str1 = null;
            //String str2=null;
            while((str1=br.readLine())!=null) {
                String[] str=str1.split("	");
                list.add(str[0]);
                list.add(str[1]);
            }
            int length=list.size();
            String[] array=list.toArray(new String[0]);
            List<Data> plist=new ArrayList<>();
            for(int i=0;i<length;) {
                plist.add(new Data(Double.parseDouble(array[i++]),Double.parseDouble(array[i++])));
            }
            Data[] data=plist.toArray(new Data[0]);
//        for(int i=0;i<(length/2);i++)
//            System.out.println(data[i].getX()+","+data[i].getY());
//        br.close();
            int[][] arr = new int[2][data.length];
            for(int i = 0;i<data.length;i++){
                arr[0][i] = (int) ((data[i].getX()*DrawMainFrame.scale*MainFrame.xTrans+DrawMainFrame.originX)*1.5);
                arr[1][i] = (int)((DrawMainFrame.originY - data[i].getY()*DrawMainFrame.scale*MainFrame.xTrans)*1.5);
            }
            return arr;
        }
    }

}


