
import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;



/*
* 该类用于初始化主面板的大的框架
* */

public class MainFrame extends JFrame implements Runnable,ActionListener, Observer {

    //private String imgFilePath = "images/map1.jpg";
    static DrawMainFrame drawMainFrame = null;
    private ParticleFilter particleFilter = null;
    private boolean isThreaAlive = true;
    static int xTrans = java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/1440;
    static int yTrans = Toolkit.getDefaultToolkit().getScreenSize().height/900;
    //static int captureCount = 1;

    private JSONUtils jsonUtils;
    private float[][] landmarks;


    CapturedBeaconMessage capturedBeaconMessage = null;
    private volatile boolean isNewMessageCome = false;
    //boolean[] isAnchorWorking = new boolean[]{false,false,false,false};
    static JTextField textx0 = new JTextField();//x0
    static JTextField texty0 = new JTextField();//y0
    static JTextField textz0 = new JTextField();//z0
    static JTextField textx1 = new JTextField();//x1
    static JTextField texty1 = new JTextField();//y1
    static JTextField textz1 = new JTextField();//z1
    static JTextField textx2 = new JTextField();//x2
    static JTextField texty2 = new JTextField();//y2
    static JTextField textz2 = new JTextField();//z2
    static JTextField textx3 = new JTextField();//x3
    static JTextField texty3 = new JTextField();//y3
    static JTextField textz3 = new JTextField();//z3
    static JTextField scaleText = new JTextField();  //scale
    static JTextField heightText = new JTextField();  //height
    static JTextField intervalText = new JTextField();  //interval
    //textx0.setText()
    static int drawCnt = 0;

    static JTextArea consoleInfoAnc;




    /*
    * MainFrame类的构造函数
    * 形成了主面板的的大部分框架
    * */


    public MainFrame(ParticleFilter particleFilter) {

        //显示当前屏幕分辨率
//        ScreenSize ss = new ScreenSize();
        int screenWidth = java.awt.Toolkit.getDefaultToolkit().getScreenSize().width;
        int screenHeight = Toolkit.getDefaultToolkit().getScreenSize().height;

        System.out.println("屏幕宽为：" + screenWidth + "---屏幕高为：" + screenHeight);


        //ImageIcon img = new ImageIcon(imgFilePath);
        //要设置的背景图片
        JLabel imgLabel = new JLabel();
        //img.setImage(img.getImage().getScaledInstance(1000,574,Image.SCALE_DEFAULT));
        //imgLabel.setIcon(img);
        //将背景图放在图片标签里。
        this.getLayeredPane().add(imgLabel, new Integer(Integer.MIN_VALUE));
        //将背景标签添加到jframe的LayeredPane面板里。

        imgLabel.setBounds(0, 0, 700, 400);//图片标签(地图区域)的位置和大小

        Container contain = this.getContentPane();
        ((JPanel) contain).setOpaque(false);


        /*
        *  显示距离的静态部分
        * */
        jsonUtils = new JSONUtils();
        landmarks = new float[4][2];
        try {
            landmarks = jsonUtils.loadAnchorPosition("config.txt");
        } catch (Exception e) {
            e.printStackTrace();
        }

        float dist01 = Algorithm.euclidianDistance(landmarks[0],landmarks[1]);
        float dist02 = Algorithm.euclidianDistance(landmarks[0],landmarks[2]);
        float dist03 = Algorithm.euclidianDistance(landmarks[0],landmarks[3]);
        float dist12 = Algorithm.euclidianDistance(landmarks[1],landmarks[2]);
        float dist13 = Algorithm.euclidianDistance(landmarks[1],landmarks[3]);
        float dist23 = Algorithm.euclidianDistance(landmarks[2],landmarks[3]);


        JLabel grdTruthLabel = new JLabel("groundtruth",JLabel.CENTER);
        grdTruthLabel.setBounds(1200*xTrans,580*yTrans,100*xTrans,25*yTrans);
        grdTruthLabel.setFont(new   java.awt.Font("Dialog",   2,   17));
        grdTruthLabel.setBorder(BorderFactory.createRaisedBevelBorder());
        this.getLayeredPane().add(grdTruthLabel);

        JLabel grdTruth01 = new JLabel(String.format("%1.2f", dist01),JLabel.CENTER);
        grdTruth01.setBounds(1200*xTrans,620*yTrans,80*xTrans,25*yTrans);
        grdTruth01.setFont(new   java.awt.Font("Dialog",   2,   17));
        grdTruth01.setBorder(BorderFactory.createRaisedBevelBorder());
        this.getLayeredPane().add(grdTruth01);

        JLabel grdTruth02 = new JLabel(String.format("%1.2f", dist02),JLabel.CENTER);
        grdTruth02.setBounds(1200*xTrans,650*yTrans,80*xTrans,25*yTrans);
        grdTruth02.setFont(new   java.awt.Font("Dialog",   2,   17));
        grdTruth02.setBorder(BorderFactory.createRaisedBevelBorder());
        this.getLayeredPane().add(grdTruth02);

        JLabel grdTruth03 = new JLabel(String.format("%1.2f", dist03),JLabel.CENTER);
        grdTruth03.setBounds(1200*xTrans,680*yTrans,80*xTrans,25*yTrans);
        grdTruth03.setFont(new   java.awt.Font("Dialog",   2,   17));
        grdTruth03.setBorder(BorderFactory.createRaisedBevelBorder());
        this.getLayeredPane().add(grdTruth03);

        JLabel grdTruth12 = new JLabel(String.format("%1.2f", dist12),JLabel.CENTER);
         grdTruth12.setBounds(1200*xTrans,710*yTrans,80*xTrans,25*yTrans);
         grdTruth12.setFont(new   java.awt.Font("Dialog",   2,   17));
         grdTruth12.setBorder(BorderFactory.createRaisedBevelBorder());
        this.getLayeredPane().add(grdTruth12);

        JLabel grdTruth13 = new JLabel(String.format("%1.2f", dist13),JLabel.CENTER);
        grdTruth13.setBounds(1200*xTrans,740*yTrans,80*xTrans,25*yTrans);
        grdTruth13.setFont(new   java.awt.Font("Dialog",   2,   17));
        grdTruth13.setBorder(BorderFactory.createRaisedBevelBorder());
        this.getLayeredPane().add(grdTruth13);

        JLabel grdTruth23 = new JLabel(String.format("%1.2f", dist23),JLabel.CENTER);
        grdTruth23.setBounds(1200*xTrans,770*yTrans,80*xTrans,25*yTrans);
        grdTruth23.setFont(new   java.awt.Font("Dialog",   2,   17));
        grdTruth23.setBorder(BorderFactory.createRaisedBevelBorder());
        this.getLayeredPane().add(grdTruth23);



        /*
        * 绘制anchor state面板上的标签
        * */
        JLabel cmdStr = new JLabel("Commands:");
        cmdStr.setBounds(1000*xTrans,5*yTrans,120*xTrans,50*yTrans);
        cmdStr.setFont(new   java.awt.Font("Dialog",   2,   19));
        this.getContentPane().add(cmdStr);

        JLabel stateStr = new JLabel("Anchor State");
        stateStr.setBounds(1100*xTrans,100*yTrans,120*xTrans,40*yTrans);
        stateStr.setFont(new   java.awt.Font("Dialog",   2,   19));
        //stateStr.setBorder(BorderFactory.createRaisedBevelBorder());
        this.getContentPane().add(stateStr);

        JLabel anchor0Str = new JLabel("Anchor 0");
        anchor0Str.setBounds(1000*xTrans,150*yTrans,100*xTrans,30*yTrans);
        anchor0Str.setFont(new   java.awt.Font("Dialog",   2,   16));
        this.getContentPane().add(anchor0Str);

        JLabel anchor1Str = new JLabel("Anchor 1");
        anchor1Str.setBounds(1000*xTrans,200*yTrans,100*xTrans,30*yTrans);
        anchor1Str.setFont(new   java.awt.Font("Dialog",   2,   16));
        this.getContentPane().add(anchor1Str);

        JLabel anchor2Str = new JLabel("Anchor 2");
        anchor2Str.setBounds(1000*xTrans,250*yTrans,100*xTrans,30*yTrans);
        anchor2Str.setFont(new   java.awt.Font("Dialog",   2,   16));
        this.getContentPane().add(anchor2Str);

        JLabel anchor3Str = new JLabel("Anchor 3");
        anchor3Str.setBounds(1000*xTrans,300*yTrans,100*xTrans,30*yTrans);
        anchor3Str.setFont(new   java.awt.Font("Dialog",   2,   16));
        this.getContentPane().add(anchor3Str);

        JLabel locationStr = new JLabel("Target Location",JLabel.CENTER);
        locationStr.setBounds(1000*xTrans,360*yTrans,130*xTrans,30*yTrans);
        locationStr.setFont(new   java.awt.Font("Dialog",   2,   17));
        locationStr.setBorder(BorderFactory.createRaisedBevelBorder());
        this.getContentPane().add(locationStr);

        JLabel processStr = new JLabel("Data Process",JLabel.CENTER);
        processStr.setBounds(1150*xTrans,360*yTrans,130*xTrans,30*yTrans);
        processStr.setFont(new   java.awt.Font("Dialog",   2,   17));
        processStr.setBorder(BorderFactory.createRaisedBevelBorder());
        this.getContentPane().add(processStr);


        /*
        * 开始画参数编辑区域
        * */
        JPanel paramConfig = new JPanel();
        paramConfig.setBackground(Color.white);
        paramConfig.setLayout(new GridLayout());
        paramConfig.setBounds(30*xTrans,560*yTrans,650*xTrans,262*yTrans);
        paramConfig.setBorder(BorderFactory.createMatteBorder(2, 2, 2, 2, Color.black) );
        this.getLayeredPane().add(paramConfig);
        paramConfig.setLayout(null);



        JLabel location = new JLabel("Location",JLabel.CENTER);
        paramConfig.add(location);
        location.setFont(new   java.awt.Font("Dialog",   2,   20));
        location.setBounds(5*xTrans,5*yTrans,100*xTrans,30*yTrans);
        location.setBorder(BorderFactory.createRaisedBevelBorder());



        JLabel x = new JLabel("X",JLabel.CENTER);
        x.setFont(new   java.awt.Font("Dialog",   1,   15));
        paramConfig.add(x);
        //x.setBorder(BorderFactory.createRaisedBevelBorder());
        x.setBounds(new Rectangle(118*xTrans, 10*yTrans, 50*xTrans, 20*yTrans));


        JLabel y = new JLabel("Y",JLabel.CENTER);
        y.setFont(new   java.awt.Font("Dialog",   1,   15));
        paramConfig.add(y);
        //y.setBorder(BorderFactory.createRaisedBevelBorder());
        y.setBounds(new Rectangle(218*xTrans, 10*yTrans, 50*xTrans, 20*yTrans));

        JLabel z = new JLabel("Z",JLabel.CENTER);
        z.setFont(new   java.awt.Font("Dialog",   1,   15));
        paramConfig.add(z);
        //z.setBorder(BorderFactory.createRaisedBevelBorder());
        z.setBounds(new Rectangle(318*xTrans, 10*yTrans, 50*xTrans, 20*yTrans));

        JLabel anchorItem0 = new JLabel("anchor 0",JLabel.CENTER);
        paramConfig.add(anchorItem0);
        anchorItem0.setFont(new   java.awt.Font("Dialog",   1,   13));
        //anchorItem0.setBorder(BorderFactory.createRaisedBevelBorder());
        anchorItem0.setBounds(new Rectangle(10*xTrans, 51*yTrans, 80*xTrans, 30*yTrans));

        //JTextField textx0 = new JTextField();//x0
        paramConfig.add(textx0);
        textx0.setBounds(101*xTrans,51*yTrans,85*xTrans,30*yTrans);
        textx0.setHorizontalAlignment(JTextField.CENTER);

        //JTextField texty0 = new JTextField();//y0
        paramConfig.add(texty0);
        texty0.setBounds(201*xTrans,51*yTrans,85*xTrans,30*yTrans);
        texty0.setHorizontalAlignment(JTextField.CENTER);

        //JTextField textz0 = new JTextField();//z0
        paramConfig.add(textz0);
        textz0.setBounds(301*xTrans,51*yTrans,85*xTrans,30*yTrans);
        textz0.setHorizontalAlignment(JTextField.CENTER);

        JLabel anchorItem1 = new JLabel("anchor 1",JLabel.CENTER);
        paramConfig.add(anchorItem1);
        anchorItem1.setFont(new   java.awt.Font("Dialog",   1,   13));
        //anchorItem1.setBorder(BorderFactory.createRaisedBevelBorder());
        anchorItem1.setBounds(10*xTrans,101*yTrans,80*xTrans,30*yTrans);

        //JTextField textx1 = new JTextField();//x1
        paramConfig.add(textx1);
        textx1.setBounds(101*xTrans,101*yTrans,85*xTrans,30*yTrans);
        textx1.setHorizontalAlignment(JTextField.CENTER);

        //JTextField texty1 = new JTextField();//y1
        paramConfig.add(texty1);
        texty1.setBounds(201*xTrans,101*yTrans,85*xTrans,30*yTrans);
        texty1.setHorizontalAlignment(JTextField.CENTER);

        //JTextField textz1 = new JTextField();//z1
        paramConfig.add(textz1);
        textz1.setBounds(301*xTrans,101*yTrans,85*xTrans,30*yTrans);
        textz1.setHorizontalAlignment(JTextField.CENTER);

        JLabel anchorItem2 = new JLabel("anchor 2",JLabel.CENTER);
        paramConfig.add(anchorItem2);
        anchorItem2.setFont(new   java.awt.Font("Dialog",   1,   13));
        //anchorItem2.setBorder(BorderFactory.createRaisedBevelBorder());
        anchorItem2.setBounds(10*xTrans,151*yTrans,80*xTrans,30*yTrans);

        //JTextField textx2 = new JTextField();//x2
        paramConfig.add(textx2);
        textx2.setBounds(101*xTrans,151*yTrans,85*xTrans,30*yTrans);
        textx2.setHorizontalAlignment(JTextField.CENTER);

        //JTextField texty2 = new JTextField();//y2
        paramConfig.add(texty2);
        texty2.setBounds(201*xTrans,151*yTrans,85*xTrans,30*yTrans);
        texty2.setHorizontalAlignment(JTextField.CENTER);

        //JTextField textz2= new JTextField();//z2
        paramConfig.add(textz2);
        textz2.setBounds(301*xTrans,151*yTrans,85*xTrans,30*yTrans);
        textz2.setHorizontalAlignment(JTextField.CENTER);

        JLabel anchorItem3 = new JLabel("anchor 3",JLabel.CENTER);
        paramConfig.add(anchorItem3);
        anchorItem3.setFont(new   java.awt.Font("Dialog",   1,   13));
        //anchorItem3.setBorder(BorderFactory.createRaisedBevelBorder());
        anchorItem3.setBounds(10*xTrans,201*yTrans,80*xTrans,30*yTrans);


        //JTextField textx3 = new JTextField();//x3
        paramConfig.add(textx3);
        textx3.setBounds(101*xTrans,201*yTrans,85*xTrans,30*yTrans);
        textx3.setHorizontalAlignment(JTextField.CENTER);

        //JTextField texty3 = new JTextField();//y3
        paramConfig.add(texty3);
        texty3.setBounds(201*xTrans,201*yTrans,85*xTrans,30*yTrans);
        texty3.setHorizontalAlignment(JTextField.CENTER);

        //JTextField textz3= new JTextField();//z3
        paramConfig.add(textz3);
        textz3.setBounds(301*xTrans,201*yTrans,85*xTrans,30*yTrans);
        textz3.setHorizontalAlignment(JTextField.CENTER);

        JLabel title2 = new JLabel("Other Parameters",JLabel.CENTER);
        paramConfig.add(title2);
        title2.setBorder(BorderFactory.createRaisedBevelBorder());
        title2.setFont(new   java.awt.Font("Dialog",   2,   19));
        title2.setBounds(new Rectangle(402*xTrans, 10*yTrans, 200*xTrans, 30*yTrans));

        JLabel textScale = new JLabel("Scale :",JLabel.CENTER);
        paramConfig.add(textScale);
        textScale.setFont(new   java.awt.Font("Dialog",   1,   13));
        textScale.setBounds(new Rectangle(402*xTrans, 51*yTrans, 80*xTrans, 30*yTrans));
        //textScale.setBorder(BorderFactory.createRaisedBevelBorder());

        JLabel textTargetHeight = new JLabel("Target Height :",JLabel.CENTER);
        paramConfig.add(textTargetHeight);
        textTargetHeight.setFont(new   java.awt.Font("Dialog",   1,   13));
        textTargetHeight.setBounds(new Rectangle(412*xTrans, 101*yTrans, 100*xTrans, 30*yTrans));
        //textTargetHeight.setBorder(BorderFactory.createRaisedBevelBorder());

        JLabel textInterval = new JLabel("Schedule Interval :",JLabel.CENTER);
        paramConfig.add(textInterval);
        textInterval.setFont(new   java.awt.Font("Dialog",   1,   13));
        textInterval.setBounds(new Rectangle(402*xTrans, 151*yTrans, 130*xTrans, 30*yTrans));
        textInterval.setHorizontalAlignment(JTextField.CENTER);
        //textInterval.setBorder(BorderFactory.createRaisedBevelBorder());

        //JTextField scaleText = new JTextField();  //scale
        paramConfig.add(scaleText);
        scaleText.setBounds(542*xTrans,51*yTrans,80*xTrans,30*yTrans);
        scaleText.setHorizontalAlignment(JTextField.CENTER);

        //JTextField heightText = new JTextField();  //height
        paramConfig.add(heightText);
        heightText.setBounds(542*xTrans,101*yTrans,80*xTrans,30*yTrans);
        heightText.setHorizontalAlignment(JTextField.CENTER);

        //JTextField intervalText = new JTextField();  //interval
        paramConfig.add(intervalText);
        intervalText.setBounds(542*xTrans,151*yTrans,80*xTrans,30*yTrans);
        intervalText.setHorizontalAlignment(JTextField.CENTER);



        JButton config = new JButton("Save");
        config.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                ParamConfig.writeText();
                JFrame dialogFrame = new  JFrame("提示");
                dialogFrame.setBounds(600*xTrans,400*yTrans,250*xTrans,150*yTrans);
                dialogFrame.setResizable(false);
                dialogFrame.setLayout(null);
                dialogFrame.setVisible(true);


                JLabel tip = new JLabel("参数设置成功!");
                tip.setBounds(72*xTrans,15*yTrans,110*xTrans,20*yTrans);
                tip.setFont(new   java.awt.Font("Dialog",   2,   16));
                //tip.setBorder(BorderFactory.createRaisedBevelBorder());
                dialogFrame.add(tip);


                JButton ok = new JButton("OK");
                ok.setBounds(87*xTrans,60*yTrans,60*xTrans,20*yTrans);
                ok.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        dialogFrame.dispose();
                        //repaint();
                    }
                });
                dialogFrame.add(ok);

            }
        });
        paramConfig.add(config);
        config.setBounds(402*xTrans,201*yTrans,100*xTrans,30*yTrans);
        config.setFont(new   java.awt.Font("Dialog",   2,   18));
        config.setBorder(BorderFactory.createRaisedBevelBorder());
        config.addActionListener(this);



        JButton load = new JButton("Load");

        load.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                ParamConfig.loadText();
                JFrame dialogFrame = new  JFrame("提示");
                dialogFrame.setBounds(600*xTrans,400*yTrans,250*xTrans,150*yTrans);
                dialogFrame.setResizable(false);
                dialogFrame.setLayout(null);
                dialogFrame.setVisible(true);


                JLabel tip = new JLabel("获取参数成功!");
                tip.setBounds(67*xTrans,15*yTrans,110*xTrans,20*yTrans);
                tip.setFont(new   java.awt.Font("Dialog",   2,   16));
                //tip.setBorder(BorderFactory.createRaisedBevelBorder());
                dialogFrame.add(tip);


                JButton ok = new JButton("OK");
                ok.setBounds(83*xTrans,60*yTrans,60*xTrans,20*yTrans);
                ok.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        dialogFrame.dispose();
                    }
                });
                dialogFrame.add(ok);

            }
        });

        paramConfig.add(load);
        load.setBounds(522*xTrans,201*yTrans,100*xTrans,30*yTrans);
        load.setFont(new   java.awt.Font("Dialog",   2,   18));
        load.setBorder(BorderFactory.createRaisedBevelBorder());


        /*
         * 在anchor状态区设置按钮
         * */
        JButton launchAllBtn = new JButton("launchAll");
        //LaunchAll.setUI(new BEButtonUI().setNormalColor(BEButtonUI.NormalColor.lightBlue));
        launchAllBtn.setFont(new   java.awt.Font("Dialog",   1,   14));
        launchAllBtn.setBorder(BorderFactory.createRaisedBevelBorder());

        JButton killAllBtn = new JButton("killAll");
        killAllBtn.setFont(new   java.awt.Font("Dialog",   1,   14));
        //KillAll.setUI(new BEButtonUI().setNormalColor(BEButtonUI.NormalColor.lightBlue));
        killAllBtn.setBorder(BorderFactory.createRaisedBevelBorder());

        JButton drawTraceBtn = new JButton("Draw Trace");
        //LaunchAll.setUI(new BEButtonUI().setNormalColor(BEButtonUI.NormalColor.lightBlue));
        drawTraceBtn.setFont(new   java.awt.Font("Dialog",   1,   12));
        drawTraceBtn.setBorder(BorderFactory.createRaisedBevelBorder());

        JButton saveDataBtn = new JButton("Save Timestamps");
        //LaunchAll.setUI(new BEButtonUI().setNormalColor(BEButtonUI.NormalColor.lightBlue));
        saveDataBtn.setFont(new   java.awt.Font("Dialog",   1,   12));
        saveDataBtn.setBorder(BorderFactory.createRaisedBevelBorder());

        JButton screenCap = new JButton("Capture Moment");
        //LaunchAll.setUI(new BEButtonUI().setNormalColor(BEButtonUI.NormalColor.lightBlue));
        screenCap.setFont(new   java.awt.Font("Dialog",   1,   12));
        screenCap.setBorder(BorderFactory.createRaisedBevelBorder());

        this.getLayeredPane().add(launchAllBtn);//killAll button
        launchAllBtn.setBounds(1120*xTrans, 20*yTrans, 110*xTrans, 40*yTrans);
        this.getLayeredPane().add(killAllBtn);//KillAll button
        killAllBtn.setBounds(1120*xTrans, 60*yTrans, 110*xTrans, 40*yTrans);
        this.getLayeredPane().add(drawTraceBtn);//drawTrace button
        drawTraceBtn.setBounds(1160*xTrans, 400*yTrans, 110*xTrans, 28*yTrans);
        this.getLayeredPane().add(saveDataBtn);//saveData button
        saveDataBtn.setBounds(1160*xTrans, 435*yTrans, 110*xTrans, 28*yTrans);
        this.getLayeredPane().add(screenCap);//saveData button
        screenCap.setBounds(1160*xTrans, 470*yTrans, 110*xTrans, 28*yTrans);

        //给按钮加入监听器
        launchAllBtn.addActionListener(new ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent e) {
                //System.out.println("666");
                ButtonThread buttonThread1 = new ButtonThread(ButtonThread.launchAll);
                buttonThread1.start();
            }
        });

        killAllBtn.addActionListener(new ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent e) {
                //System.out.println("777");
                ButtonThread buttonThread1 = new ButtonThread(ButtonThread.killAll);
                buttonThread1.start();
            }
        });

        drawTraceBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                //DrawSmoothCurve.createAndShowGui();
                DrawSmoothCurve d = new DrawSmoothCurve();
                d.createAndShowGui();
            }
        });

        saveDataBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    saveTimestamps();
                } catch (Exception e1) {
                    e1.printStackTrace();
                }
            }
        });

        screenCap.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                capturePic();
            }
        });



        /*
        *   the console information in the JTextArea
        * */
        JLabel console = new JLabel("Uploaded Message From Clients",JLabel.CENTER);
        Font font = new   java.awt.Font("Dialog",   2,   17);
        console.setFont(font);
        console.setBorder(BorderFactory.createRaisedBevelBorder());
        console.setBounds(750 * xTrans,527 * yTrans,250 * xTrans,35 * yTrans);
        this.getContentPane().add(console);
        Font consoleFont = new   java.awt.Font("Dialog",   2,   14);

        /*
         *   the console information in the JTextArea
         * */
        JLabel distanceDisplay = new JLabel("distance comparison",JLabel.CENTER);
        distanceDisplay.setFont(font);
        distanceDisplay.setBorder(BorderFactory.createRaisedBevelBorder());
        distanceDisplay.setBounds(1150 * xTrans,527 * yTrans,200 * xTrans,35 * yTrans);
        this.getContentPane().add(distanceDisplay);


        // the area which show message from anchor
        consoleInfoAnc = new JTextArea();
        //consoleInfo.setBounds(100,100,100,100);
        consoleInfoAnc.setFont(consoleFont);
        JScrollPane consoleShowAnc = new JScrollPane(consoleInfoAnc);
        consoleShowAnc.setBounds(700 * xTrans,570 * yTrans,350 * xTrans,290 * yTrans);
        this.getContentPane().add(consoleShowAnc);


        JLabel sendLabel = new JLabel("distance",JLabel.CENTER);
        sendLabel.setFont(font);
        sendLabel.setBorder(BorderFactory.createRaisedBevelBorder());
        sendLabel.setBounds(1300 * xTrans,580 * yTrans,100 * xTrans,25 * yTrans);
        this.getContentPane().add(sendLabel);


        JLabel distance01 = new JLabel("0-1",JLabel.CENTER);
        distance01.setFont(font);
        distance01.setBorder(BorderFactory.createRaisedBevelBorder());
        distance01.setBounds(1100 * xTrans,620 * yTrans,60 * xTrans,35 * yTrans);
        this.getContentPane().add(distance01);

        JLabel distance02 = new JLabel("0-2",JLabel.CENTER);
        distance02.setFont(font);
        distance02.setBorder(BorderFactory.createRaisedBevelBorder());
        distance02.setBounds(1100 * xTrans,650 * yTrans,60 * xTrans,35 * yTrans);
        this.getContentPane().add(distance02);

        JLabel distance03 = new JLabel("0-3",JLabel.CENTER);
        distance03.setFont(font);
        distance03.setBorder(BorderFactory.createRaisedBevelBorder());
        distance03.setBounds(1100 * xTrans,680 * yTrans,60 * xTrans,35 * yTrans);
        this.getContentPane().add(distance03);

        JLabel distance12 = new JLabel("1-2",JLabel.CENTER);
        distance12.setFont(font);
        distance12.setBorder(BorderFactory.createRaisedBevelBorder());
        distance12.setBounds(1100 * xTrans,710 * yTrans,60 * xTrans,35 * yTrans);
        this.getContentPane().add(distance12);

        JLabel distance13 = new JLabel("1-3",JLabel.CENTER);
        distance13.setFont(font);
        distance13.setBorder(BorderFactory.createRaisedBevelBorder());
        distance13.setBounds(1100 * xTrans,740 * yTrans,60 * xTrans,35 * yTrans);
        this.getContentPane().add(distance13);

        JLabel distance23 = new JLabel("2-3",JLabel.CENTER);
        distance23.setFont(font);
        distance23.setBorder(BorderFactory.createRaisedBevelBorder());
        distance23.setBounds(1100 * xTrans,770 * yTrans,60 * xTrans,35 * yTrans);
        this.getContentPane().add(distance23);





/*
* 设置主Frame
* */

        ((JPanel) contain).setOpaque(false);
        // 将内容面板设为透明。将LayeredPane面板中的背景显示出来。
        //this.add(new MyPanel2());
        this.particleFilter = particleFilter;
        drawMainFrame = new DrawMainFrame(this.particleFilter,particleFilter.getTdoaCalUtil());
        this.add(drawMainFrame);
        drawMainFrame.setBackground(null);
        drawMainFrame.setOpaque(false);



        this.setVisible(true);
        this.setResizable(false);
        //this.setSize(1500,800);//整个窗体的大小
        this.setBounds(0, 0, 1500, 900);
        this.setTitle("Asynchronous Localization Project: by cc at HUST");
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);//指定界面默认关闭选项  EXIT_ON_CLOSE为关闭时退出程序
        //this.setLocationRelativeTo(null);// 把窗口位置设置到屏幕的中心
        System.out.println(getLocation());
        //DrawSmoothCurve.createAndShowGui();

    }



    //构造方法结束**************************************

    public void getCapturedBeaconMessage(CapturedBeaconMessage beaconMessage) {
        this.capturedBeaconMessage = beaconMessage;
        isNewMessageCome = true;
    }

    @Override//信号灯事件
    public void actionPerformed(ActionEvent e) {

    }

    @Override
    public void update(String msg) {

    }

    @Override
    public void run() {
        drawMainFrame.initDrawingParameters();
        while (isThreaAlive) {
            if(isNewMessageCome == true){
                isNewMessageCome = false;
                drawMainFrame.prepareAnchorState(capturedBeaconMessage);//  if "isNewMessageCome" is true , make drawMainFrame's "isMessageRecv" true
            }
            drawMainFrame.repaint();
            /*
            *   in drawMainFrame's paint() , if isMessageRecv is true , anchor will be lighted with green color
            * */

            try {
                Thread.sleep(10);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public DrawMainFrame getDrawMainFrame(){
        return drawMainFrame;
    }

    public void capturePic() {
        try {
            Robot rb = null; // java.awt.image包中的类，可以用来抓取屏幕，即截屏。
            rb = new Robot();
            Toolkit tk = Toolkit.getDefaultToolkit(); // 获取缺省工具包
            Dimension di = tk.getScreenSize(); // 屏幕尺寸规格
            Rectangle rec = new Rectangle(this.getLocation().x, this.getLocation().y, drawMainFrame.xAxisLength + 60 * xTrans, drawMainFrame.yAxisLength + 60 * yTrans);
            BufferedImage bi = rb.createScreenCapture(rec);

            System.out.println();
            SimpleDateFormat sdf = new SimpleDateFormat("MM.dd.HH.mm.ss");
            ImageIO.write(bi, "jpg", new File("captured_pic/experiment@" + sdf.format(new Date()) + ".jpg"));

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void saveTimestamps()throws Exception{
        //剪切timestamps文件到timestamps文件夹中
        File srcDir = new File("debug");
        File[] timestampSrcFiles = srcDir.listFiles();
        for (File srcFile : timestampSrcFiles){
            FileUtils.cutGeneralFile(srcFile.getAbsolutePath(),"timestamps");
        }

        //将results目录下产生的新的localization.txt文件复制到timestamps文件夹中，以便与anchor的timestamps文件一个压缩
        //File latestLocationDir = new File("results");
        File latestLocationFile = FileUtils.getLatestLocationFile("results");
        //latestLocationFile.renameTo(new File("timestamps/" + latestLocationFile.getName()));
        System.out.println("latest location file is :" + latestLocationFile.getName());
        FileUtils.copyGeneralFile(latestLocationFile.getPath(),"timestamps");


        //将timestamps文件夹弄成压缩包，并放在指定位置
        SimpleDateFormat df = new SimpleDateFormat("MM_dd_HH.mm.ss");//设置日期格式
        String zipFileName = "experiment_results/timestamps@" + df.format(new Date()) + ".zip";
        FileOutputStream fos1 = new FileOutputStream(new File(zipFileName));
        FileUtils.toZip("timestamps", fos1,true);

        //将timestamps文件夹中的文件清空，便于下次压缩
        File timestampsDestFile = new File("timestamps");
        File[] timestampsDestFiles = timestampsDestFile.listFiles();
        for (File redundantTsFile : timestampsDestFiles){
            FileUtils.deleteGeneralFile(redundantTsFile.getPath());
        }
    }
}
//■●





//以下代码用于获取当前屏幕分辨率
//class ScreenSize {
//    private int screenWidth;
//    private int screenHeight;
//
//    public int getScreenWidth() {
//
//        setScreenWidth(java.awt.Toolkit.getDefaultToolkit().getScreenSize().width);
//        return screenWidth;
//    }
//
//    public void setScreenWidth(int screenWidth) {
//        this.screenWidth = screenWidth;
//    }
//
//    public int getScreenHeight() {
//        setScreenHeight(java.awt.Toolkit.getDefaultToolkit().getScreenSize().height);
//        return screenHeight;
//    }
//
//    public void setScreenHeight(int screenHeight) {
//        this.screenHeight = screenHeight;
//    }
//}









