public interface FlagVar {

    String identityStr = "identity";
    String upStr = "up";
    String downStr = "down";
    String tdoaStr = "tdoa";

}
