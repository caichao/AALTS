import org.json.JSONObject;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.*;

public class ButtonThread extends Thread {
    // This thread is used to schedule the anchor for signal transmission

    private final int portNum = 55555;
    private boolean isScheduleLive = true;
    private boolean isTimeToBroadcastMessage = true;
    private String messageWrapper = null;
    private int bufferLength = 1024;
    //public static final int schedualInterval = 1000; // unit in microseconds
    private byte[] buffer = new byte[bufferLength];
    private String command = null;

    public static final String launchAll = "tmux new -s main -d \"sudo ./main\"";
    public static final String killAll = "sudo pkill main";
    public static final String comm = "vim Server.sh";
    private static final String PI01 = "192.168.1.200";
    private static final String PI02 = "192.168.1.126";
    private static final String PI03 = "192.168.1.114";
    private static final String PI04 = "192.168.1.202";
    private String username = "pi";
    private String password = "cc";
    private Process process;

    public ButtonThread(String c){
        this.command = c;
    }
    public void setCommands(String c){
        this.command = c;
    }

    private void logInAll(){
        //process = Runtime.getRuntime().exec();
    }

    private void launchAll() throws IOException {
        launchOne(PI01);
        launchOne(PI02);
        launchOne(PI03);
        launchOne(PI04);
    }

    private void launchOne(String pi) throws IOException {

    }

    @Override
    public void run() {
        super.run();
        try{
            DatagramSocket socket = new DatagramSocket();
            byte[] arr = this.command.getBytes();
            DatagramPacket packet = new DatagramPacket(arr, arr.length,InetAddress.getByName("255.255.255.255") , portNum);

            int i = 0;
            socket.send(packet);
//            System.out.println("Send a broadcast command message" + (++i));
            socket.close();
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
