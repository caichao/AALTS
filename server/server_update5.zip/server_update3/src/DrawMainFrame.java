import javax.swing.*;
import java.awt.*;
import java.util.List;

/****
* 该类用于画出主面板上动态显示的一些东西
* ****/

class DrawMainFrame extends JPanel {


    ParticleFilter particleFilter = null;
    BasicStroke basicStroke = null;       // 笔画的轮廓（画笔宽度/线宽为3px）
    BasicStroke boldStroke = null;

    float[][] particles = null;
    float[][] allParticles = null;
    float landmarks[][] = null;
    JSONUtils jsonUtils = null;
    String configFilePath = "config.txt";

    private int currentActivateAnchorId = 0;
    private boolean isMessageRecv = false;
    static int xTrans = java.awt.Toolkit.getDefaultToolkit().getScreenSize().width/1440;
    static int yTrans = Toolkit.getDefaultToolkit().getScreenSize().height/900;
    int numberOfParticles = ParticleFilter.topParticleNumber;
    static int xInerAxis = 0;//(int) (getMaxXCoordinates() * scale);
    static int yInerAxis = 0; //(int) (getMaxYCoordinates() * scale);
    boolean[] isAnchorWorking = new boolean[]{false,false,false,false};

    List locationQueue = null;
    private int queueLength;

    private float[] distancesOf2;

    private static int startCorX = 1100 * xTrans;
    //private static int startCorY = 580 * yTrans;
    private static int start00Y = 620 * yTrans;
    private static int start01Y = 650 * yTrans;
    private static int start02Y = 680 * yTrans;
    private static int start03Y = 710 * yTrans;

    private static int recvCorX = 1300 * xTrans;
    //private static int recvCorY = 580 * yTrans;
    private static int recv00Y = 620 * yTrans;
    private static int recv01Y = 650 * yTrans;
    private static int recv02Y = 680 * yTrans;
    private static int recv03Y = 710 * yTrans;

    private UpdateDistanceCallback callback;

    /*
     * 地图相关参数
     * */
     static float scale ;              //放大尺度
     static int originX = 35*xTrans;               //原点的x
     static int originY = 520*yTrans;              //原点的y
     static int xAxisLength = 900*xTrans;         //X轴长度
     static int yAxisLength = 510*yTrans;          //Y轴长度
     static int AnchorScale = 20;           //正方形Anchor边长的一半


    Font font = null;


    public void refreshParticleLocation() {
        repaint();
    }

    public float getMaxXCoordinates() {
        float maxXCoordinates = 0;
        for (int i = 0; i < landmarks.length; i++) {
            if (landmarks[i][0] > maxXCoordinates) {
                maxXCoordinates = landmarks[i][0];
            }
        }
        return maxXCoordinates;//4.623
    }

    public float getMaxYCoordinates() {
        float maxYCoordinates = 0;
        for (int i = 0; i < landmarks.length; i++) {
            if (landmarks[i][1] > maxYCoordinates) {
                maxYCoordinates = landmarks[i][1];
            }

        }
        return maxYCoordinates;//2.662
    }


    public DrawMainFrame(ParticleFilter particleFilter,UpdateDistanceCallback callback) {
        this.particleFilter = particleFilter;
        this.callback = callback;
        this.locationQueue = particleFilter.getLocationQueue();
        queueLength = particleFilter.getLocationQueueLength();
        this.setOpaque(false);
        initDrawingParameters();
    }

    public void initDrawingParameters() {
        basicStroke = new BasicStroke(3);
        boldStroke = new BasicStroke(5);
        font = new Font("宋体", Font.BOLD, 15);
        //particles = particleFilter.getParticles().clone(); // deep copy
        //int index[] = particleFilter.topK(particleFilter.getWeights(), numberOfParticles);
        particles = new float[numberOfParticles][2];
        allParticles = particleFilter.getParticles();

        try {
            landmarks = jsonUtils.loadAnchorPosition(configFilePath);
            scale = JSONUtils.getMapGUIScaleCoefficient(configFilePath);
            //targetLocation=jsonUtils.loadAnchorPosition("localization_2018-07-20_14_56_23.txt");

        } catch (Exception e) {
            e.printStackTrace();
        }
        xInerAxis = (int) (getMaxXCoordinates() * scale);
        yInerAxis =  (int) (getMaxYCoordinates() * scale);

    }

    public void copyTopParticles(int n) {
        int index[] = Algorithm.topK(particleFilter.getWeights(), n);
        for (int i = 0; i < n; i++) {
            particles[i] = allParticles[index[i]];
        }
    }

    /*
     * 画anchor状态框、曲线显示框等需要draw的组件
     *
     * */
    public void paintComponent(Graphics2D g){
        //大框
        //g.drawString("123456",1200,280);
        int screenWidth = java.awt.Toolkit.getDefaultToolkit().getScreenSize().width;
        int screenHeight = Toolkit.getDefaultToolkit().getScreenSize().height;
        g.setStroke(new BasicStroke(2.0f));
        g.drawRect(990*xTrans,10*yTrans,310*xTrans,500*yTrans);
        //小框
        g.setStroke(new BasicStroke(0.5f));
        g.drawLine(990*xTrans,105*yTrans,1300*xTrans,105*yTrans);
        g.drawLine(990*xTrans,355*yTrans,1300*xTrans,355*yTrans);
    }

    /***************** the paint method ********************
     *  draw all the dynamic things
     * */
    public void paint(Graphics g) {

        super.paint(g);
        Graphics2D g2 = (Graphics2D) g;

        g2.setStroke(basicStroke);
        g2.setColor(Color.WHITE);
        // first erase the last particles 擦除旧点
        if (particles != null) {
            for (int i = 0; i < this.particles.length; i++) {
                drawPoints(particles[i][0], particles[i][1], g2);
            }
        }
            //System.out.println("DrawMainFrame's paint() run!!!");

        copyTopParticles(numberOfParticles);
        // second draw the new particles  画新点
        g2.setColor(Color.RED);
        for (int i = 0; i < particles.length; i++) {
            drawPoints(particles[i][0], particles[i][1], g2);
        }


        // draw the estimated locations
        g2.setColor(Color.GREEN);
        g2.setStroke(boldStroke);
        //drawEstimatedLocation(, 1, g2);
        //drawEstimatedLocation(particleFilter.getX(), particleFilter.getY(), g2);
        drawEstimatedLocations(locationQueue,g2);

        //draw axis
        g2.setColor(Color.cyan);
        g2.setStroke(new BasicStroke(2.0f));
        drawAxis(originX, originY, g2);

        //draw the up and down border
        g2.setColor(Color.CYAN);
        //g2.setStroke(new BasicStroke(2.0f));
        Stroke dash = new BasicStroke(2.5f, BasicStroke.CAP_BUTT,
                BasicStroke.JOIN_ROUND, 3.5f, new float[]{5, 5,},
                0f);
        g2.setStroke(dash);
        drawBorder(originX, originY, g2);

        // add labels for the estimated locations
        g2.setColor(Color.darkGray);
        //drawLabels(particleFilter.getX(), particleFilter.getY(), String.format( " (%.2f ,  %.2f ,  %.2f)", particleFilter.getX(), particleFilter.getY(), particleFilter.getZ()), g2);
        g2.setFont(new   java.awt.Font("Dialog",   2,   18));

        //更新定位位置
        g2.drawString(String.format( " x = %.2f ", particleFilter.getX()),1005*MainFrame.xTrans, 420*MainFrame.yTrans);
        g2.drawString(String.format( " y = %.2f ", particleFilter.getY()),1005*MainFrame.xTrans, 450*MainFrame.yTrans);
        g2.drawString(String.format( " z = %.2f ", particleFilter.getZ()),1005*MainFrame.xTrans, 480*MainFrame.yTrans);


        //画出distance比较




        // draw Anchor and their send state
        g2.setColor(Color.BLACK);
        g2.setStroke(new BasicStroke(1.5f));
        drawAnchor(AnchorScale, g2,1);

        paintComponent(g2);
        initAnchorState(g2);
        //for test
        /*freshAnchorState(g2, 0);
        drawAnchorWorkingState(g2);*/
        if(isMessageRecv) {
            //擦除上次被点亮的anchor，并点亮当前发出声音的anchor
            freshAnchorState(g2, currentActivateAnchorId);
            //draw the anchor which has worked
            drawAnchorWorkingState(g2);
        }

        paintDistance(g2);
        /*g2.drawString("123",1250,645);
        g2.drawString("123",1250,675);
        g2.drawString("123",1250,705);
        g2.drawString("123",1250,735);*/
        //System.out.println("refresh");
        repaint();
    }


    private void paintDistance(Graphics2D g){
        g.setFont(new   java.awt.Font("Dialog",   2,   20));
        g.setColor(Color.RED);
        synchronized (this){
            distancesOf2 = callback.getDistances();
            g.drawString(String.valueOf(distancesOf2[0]),1350 * xTrans,645 * yTrans);
            g.drawString(String.valueOf(distancesOf2[1]),1350 * xTrans,675 * yTrans);
            g.drawString(String.valueOf(distancesOf2[2]),1350 * xTrans,705 * yTrans);
            g.drawString(String.valueOf(distancesOf2[3]),1350 * xTrans,735 * yTrans);
            g.drawString(String.valueOf(distancesOf2[4]),1350 * xTrans,765 * yTrans);
            g.drawString(String.valueOf(distancesOf2[5]),1350 * xTrans,795 * yTrans);
        }
    }


    public void prepareAnchorState(CapturedBeaconMessage capturedBeaconMessage){
        if (capturedBeaconMessage.selfAnchorId <100){
            isAnchorWorking[capturedBeaconMessage.selfAnchorId] = true;
            currentActivateAnchorId = capturedBeaconMessage.capturedAnchorId;
            isMessageRecv = true;
        }
    }

    //draw particles
    public void drawPoints(float x, float y, Graphics2D g) {
        g.drawLine((int) (x * scale*xTrans + originX), (int) (originY - y * scale*yTrans), (int) (x * scale*xTrans + originX), (int) (originY - y * scale*yTrans));
    }
        /*
        public void drawEstimatedLocation(float x, float y, Graphics2D g){
            g.drawLine((int)(x * scale) - 5,(int)(y * scale), (int)(x * scale)+5,(int)(y * scale));
            g.drawLine((int)(x * scale), (int)(y * scale)+5, (int)(x * scale), (int)(y * scale)-5);
        }
        */

    //画估计位置
    public void drawEstimatedLocation(float x, float y, Graphics2D g) {
        g.drawLine((int) ((x*scale *xTrans+ originX)) - 5, (int) (originY - y*scale*yTrans), (int) ((x*scale*xTrans + originX) ) + 5, (int) (originY - y*scale*yTrans));
        g.drawLine((int) (x*scale *xTrans+ originX), (int) ((originY - y*scale*yTrans) )+ 5, (int) (x*scale *xTrans+ originX), (int) ((originY - y*scale*yTrans) ) - 5);
    }

    //画5个位置
    public void drawEstimatedLocations(List locationQueue, Graphics2D g){
        if (locationQueue.size() <= queueLength){
            for (int i = 0;i < locationQueue.size();i++){
                List axisArray = (List) locationQueue.get(i);
                drawEstimatedLocation((float)axisArray.get(0),(float)axisArray.get(1),g);
            }
        }
    }

    public void drawAxis(float x, float y, Graphics2D g) {
        drawAxisX(x, y, g);
        drawAxisY(x, y, g);
    }

    //画x轴
    public  void drawAxisX(float x, float y, Graphics2D g) {
        g.drawLine((int) x, (int) y, (int) x + xAxisLength, (int) y);
        g.drawLine((int) x + xAxisLength, (int) y, (int) x + xAxisLength - 5, (int) y - 2);
        g.drawLine((int) x + xAxisLength, (int) y, (int) x + xAxisLength - 5, (int) y + 2);
        g.setFont(new Font("宋体", Font.BOLD, 20));
        g.drawString("X", (int) x + xAxisLength + 5, (int) y);

    }

    //画y轴
    public void drawAxisY(float x, float y, Graphics2D g) {
        g.drawLine((int) x, (int) y, (int) x, (int) y - yAxisLength);
        g.drawLine((int) x, (int) y - yAxisLength, (int) x - 2, (int) y - yAxisLength + 5);
        g.drawLine((int) x, (int) y - yAxisLength, (int) x + 2, (int) y - yAxisLength + 5);
        g.setFont(new Font("宋体", Font.BOLD, 20));
        g.drawString("Y", (int) x - 15, (int) y - yAxisLength + 5);
    }

    //画上、右边界
    public void drawBorder(float x, float y, Graphics2D g) {
        int screenWidth = java.awt.Toolkit.getDefaultToolkit().getScreenSize().width;
        int screenHeight = Toolkit.getDefaultToolkit().getScreenSize().height;

        g.drawLine((int) (x + 2), (int) (y - yInerAxis*yTrans), (int) (x + xInerAxis*xTrans), (int) (y - yInerAxis*yTrans));//上边界
        g.drawLine((int) (x + xInerAxis*xTrans), (int) y, (int) (x + xInerAxis*xTrans), (int) (y - yInerAxis*yTrans));//右边界
        g.setFont(new Font("宋体", Font.BOLD, 15));
        g.setColor(Color.black);
        g.drawString(String.valueOf(getMaxXCoordinates()) + "m", (int) (x + 17 + xInerAxis)*xTrans , (originY + 16) * yTrans);
        g.drawString(String.valueOf(getMaxYCoordinates()) + "m", (originX + 3) * xTrans, (int) (y - yInerAxis - 19) *yTrans);
    }

    //画出信号指向
    public void drawTransArrow(int xs,int ys,int xe,int ye,Graphics2D g){
        g.drawLine(xs,ys,xe,ye);
    }


        /*
        //画坐标标签
        public void drawLabels(float x, float y, String msg, Graphics2D g) {
            //g.setFont(font);
            g.setFont(new   java.awt.Font("Dialog",   1,   18));
            g.drawString(msg, 1000, 500);

        }
        */

    //画Anchor
    public void drawAnchor(int r, Graphics2D g, int type) {
        String ss[] = new String[]{"0", "1", "2", "3"};
        if(type==1) {
            for (int i = 0; i < 4; i++) {
                g.drawRect((int) (landmarks[i][0] * scale * xTrans) - r / 2 * xTrans + originX, (originY - (int) (landmarks[i][1] * scale * yTrans) - r / 2 * yTrans), r * xTrans, r * yTrans);
                g.drawString(ss[i], ((landmarks[i][0] * scale * xTrans + originX) - (r) / 4), ((originY - landmarks[i][1] * scale * yTrans) + (r - 4 - r / 2)));
            }
        }
        else if(type==2){
            for (int i = 0; i < 4; i++) {
                g.drawRect((int) (((landmarks[i][0] * scale * xTrans) - r / 2 * xTrans + originX)*1.5), (int) (((originY - (int) (landmarks[i][1] * scale * yTrans) - r / 2 * yTrans))*1.5), (int) (r * xTrans*1.5), (int) (r * yTrans*1.5));
                g.drawString(ss[i], (int) (((landmarks[i][0] * scale * xTrans + originX) - (r) / 4+2)*1.5), (int) (((originY - landmarks[i][1] * scale * yTrans) + (r - 4 - r / 2)-2)*1.5));
            }
        }
    }


    //画当前发送消息的anchor的指示灯
    public void freshAnchorState(Graphics2D g,int AnchorNum) {
        int screenWidth = java.awt.Toolkit.getDefaultToolkit().getScreenSize().width;
        int screenHeight = Toolkit.getDefaultToolkit().getScreenSize().height;
        g.setFont(new Font("MS 明朝", Font.BOLD, 20));
        g.setStroke(new BasicStroke(4f));

        //清除上一次的指示灯
        g.setColor(Color.WHITE);
        for(int i = 0;i<4;i++)
        {
            g.drawRect((int) ((landmarks[i][0] * scale*xTrans + originX - AnchorScale / 2*xTrans) - 3*xTrans), (int) ((originY - landmarks[i][1] * scale*yTrans - AnchorScale / 2*yTrans) - 3*yTrans), (AnchorScale + 7)*xTrans, (AnchorScale + 7)*yTrans);
        }


        //画出正在发送信息的Anchor指示灯(绿)
        g.setColor(Color.GREEN);
        switch(AnchorNum){
            case 0:
            {g.drawRect((int) ((landmarks[0][0] * scale*xTrans + originX - AnchorScale / 2*xTrans) - 3*xTrans), (int) ((originY - landmarks[0][1] * scale*yTrans - AnchorScale / 2*yTrans) - 3*yTrans), (AnchorScale + 7)*xTrans, (AnchorScale + 7)*yTrans);
                isAnchorWorking[0]=true;
                break;}
            case 1:
            {g.drawRect((int) ((landmarks[1][0] * scale*xTrans + originX - AnchorScale / 2*xTrans) - 3*xTrans), (int) ((originY - landmarks[1][1] * scale*yTrans - AnchorScale / 2*yTrans) - 3*yTrans), (AnchorScale + 7)*xTrans, (AnchorScale + 7)*yTrans);
                isAnchorWorking[1]=true;
                break;}
            case 2:
            {g.drawRect((int) ((landmarks[2][0] * scale*xTrans + originX - AnchorScale / 2*xTrans) - 3*xTrans), (int) ((originY - landmarks[2][1] * scale*yTrans - AnchorScale / 2*yTrans) - 3*yTrans), (AnchorScale + 7)*xTrans, (AnchorScale + 7)*yTrans);
                isAnchorWorking[2]=true;
                break;}
            case 3:
            {g.drawRect((int) ((landmarks[3][0] * scale*xTrans + originX - AnchorScale / 2*xTrans) - 3*xTrans), (int) ((originY - landmarks[3][1] * scale*yTrans - AnchorScale / 2*yTrans) - 3*yTrans), (AnchorScale + 7)*xTrans, (AnchorScale + 7)*yTrans);
                isAnchorWorking[3]=true;
                break;}
        }
    }


    public void initAnchorState(Graphics2D g){
        //g.setFont(new Font("宋体", Font.BOLD, 20));
        int screenWidth = java.awt.Toolkit.getDefaultToolkit().getScreenSize().width;
        int screenHeight = Toolkit.getDefaultToolkit().getScreenSize().height;

        g.setStroke(new BasicStroke(1f));
        g.setFont(new   java.awt.Font("Dialog",   3,   15));
        g.setColor(Color.BLACK);
        //g.drawString("Anchor state",1150,140);
//            g.drawString("Anchor_0:",1000,180);
//            g.drawString("Anchor_1:",1000,230);
//            g.drawString("Anchor_2:",1000,280);
//            g.drawString("Anchor_3:",1000,330);

        g.setFont(new Font("宋体", Font.BOLD, 40));
        g.setColor(Color.red);
        for(int i =0;i<4;i++){
            g.drawString("■",1130*xTrans,(185+i*50)*yTrans);
        }
    }


    public void drawAnchorWorkingState(Graphics2D g)
    {

        int screenWidth = java.awt.Toolkit.getDefaultToolkit().getScreenSize().width;
        int screenHeight = Toolkit.getDefaultToolkit().getScreenSize().height;
        for(int i =0;i<4;i++){
            g.setFont(new Font("宋体", Font.BOLD, 40));
            if(isAnchorWorking[i]==true){
                g.setColor(Color.white);
                g.drawString("■",1130*xTrans,(185+i*50)*yTrans);
                g.setColor(Color.green);
                g.drawString("●",1130*xTrans,(185+i*50)*yTrans);
            }
            else{
                g.setColor(Color.red);
                g.drawString("■",1130*xTrans,(185+i*50)*yTrans);
            }
        }
    }

    public interface UpdateDistanceCallback{
        float[] getDistances();
    }
}